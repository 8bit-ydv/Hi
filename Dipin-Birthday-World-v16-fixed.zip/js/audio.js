/* =============================================================
   AUDIO — a score composed live in your browser
   -------------------------------------------------------------
   No audio file. Every note is synthesised on the fly with
   WebAudio and follows the journey scene by scene, movement by
   movement:

     • a warm detuned pad carries every chord
     • a music-box celesta plays the melody and arpeggios
     • high bells arrive at the rooftop and the reveal
     • a whisper of night air breathes under scene i
     • chords change WITH the pictures in the memory film
     • the melody literally climbs the stairs with the camera
     • the make-a-wish moment hushes everything but the pad

   One look-ahead scheduler (8th-note grid), mood tables per
   scene, and smooth filter/gain ramps — scrubbing backwards
   simply plays the journey back in musical reverse.

   Playback only ever begins from a real user gesture.
   ============================================================= */
(function (w) {
  const CFG = (w.BDAY_CONFIG && w.BDAY_CONFIG.audio) || {};
  const VOL = CFG.volume ?? 0.8;

  const A = {
    supported: !!(w.AudioContext || w.webkitAudioContext),
    enabled: false, ready: false,
    ctx: null, master: null, tone: null, delay: null,
    progress: 0, mood: "night", moodArg: 0, climb: 0,
    step: 0, nextT: 0, timer: null, bar: 0
  };

  /* ---------- tuning ---------- */
  const BPM = 72, EIGHTH = 60 / BPM / 2, BAR = EIGHTH * 8;
  const N = m => 440 * Math.pow(2, (m - 69) / 12);

  /* mood table — each scene is a different PIECE: its own tempo,
     time signature, key and instruments, so the changes are unmistakable */
  const MOODS = {
    night:    { bpm: 60, sig: 4, key: 0,   pad: 1,   box: 0,   pluck: 0,   bells: 0,   air: 1,   heart: 0, lp: 1600, g: 0.50,
                chords: [[45,57,64,71],[41,53,60,67]] },
    years:    { bpm: 60, sig: 4, key: 0,   pad: 0.8, box: 0.55, pluck: 0,   bells: 0.2, air: 0.5, heart: 0, lp: 2100, g: 0.54,
                chords: [[45,57,64,71],[43,55,62,69],[41,53,60,67],[40,52,59,64]] },   // a ticking music-box timeline
    road:     { bpm: 96, sig: 4, key: 7,  pad: 1,   box: 0.6, pluck: 1,   bells: 0,   air: 0,   heart: 0, lp: 4400, g: 0.72,
                chords: [[43,55,62,69],[48,55,64,71],[45,57,64,72],[41,53,60,67]] },  // a warm drive,
    fall:     { bpm: 66, sig: 4, key: 0,   pad: 0.7, box: 1,   pluck: 0,   bells: 0,   air: 0.3, heart: 0, lp: 2600, g: 0.62,
                chords: [[45,57,64,71],[41,53,60,67],[36,48,55,64],[43,55,62,69]] },
    warm:     { bpm: 92, sig: 4, key: 5,   pad: 1,   box: 1,   pluck: 1,   bells: 0,   air: 0,   heart: 0, lp: 4600, g: 0.74,
                chords: [[41,53,60,67],[43,55,62,67],[45,57,64,71],[48,55,64,72]] },
    approach: { bpm: 72, sig: 4, key: 5,   pad: 1,   box: 0.6, pluck: 0.6, bells: 0,   air: 0,   heart: 0, lp: 5200, g: 0.80,
                chords: [[48,55,60,67],[43,55,62,67],[45,57,64,72],[41,53,60,69]] },
    interior: { bpm: 84, sig: 3, key: 5,   pad: 1,   box: 1,   pluck: 1,   bells: 0,   air: 0,   heart: 0, lp: 4200, g: 0.68,
                chords: [[41,52,60,67],[38,50,57,65]] },                    // the house WALTZ (3/4)
    wishes:   { bpm: 60, sig: 3, key: 7,   pad: 1,   box: 1,   pluck: 0,   bells: 0.5, air: 0.4, heart: 0, lp: 3000, g: 0.60,
                chords: [[43,54,62,69],[40,52,59,66]] },                    // dreamy waltz a step up
    wish:     { bpm: 52, sig: 4, key: 5,   pad: 0.7, box: 0,   pluck: 0,   bells: 0,   air: 0,   heart: 1, lp: 2000, g: 0.30,
                chords: [[41,53,60,67]] },
    cut:      { bpm: 84, sig: 3, key: 5,   pad: 1,   box: 1,   pluck: 0.8, bells: 0,   air: 0,   heart: 0, lp: 3200, g: 0.55,
                chords: [[48,55,64,71],[41,52,60,67]] },
    darkroom: { bpm: 56, sig: 4, key: -4,  pad: 1,   box: 0.35, pluck: 0,  bells: 0,   air: 0.5, heart: 0, lp: 1400, g: 0.50,
                chords: [[40,52,59,66],[38,50,57,63]] },                    // drops LOW and dark
    rooftop:  { bpm: 96, sig: 4, key: 7,   pad: 1,   box: 1,   pluck: 1,   bells: 0.6, air: 0,   heart: 0, lp: 5400, g: 0.78,
                chords: [[41,53,60,67],[43,55,62,69],[48,55,64,72],[45,57,64,71]] },
    finale:   { bpm: 96, sig: 4, key: 12,  pad: 1,   box: 1,   pluck: 1,   bells: 1,   air: 0,   heart: 0, lp: 6200, g: 0.85,
                chords: [[48,55,64,72],[43,55,62,71],[41,53,60,69],[48,60,67,76]] },  // everything an octave up
    outro:    { bpm: 60, sig: 4, key: 0,   pad: 1,   box: 1,   pluck: 0,   bells: 0.3, air: 0.4, heart: 0, lp: 3000, g: 0.55,
                chords: [[45,57,64,71],[41,53,60,67]] }                     // home key again — a lullaby
  };
  /* the memory film: one chord per photograph */
  const FILM_CHORDS = [
    [45,57,64,71],   // Am add9
    [41,53,60,67],   // F maj7
    [36,48,55,64],   // C
    [43,55,62,69],   // G6
    [45,57,64,72],   // Am/E
    [41,53,60,69],   // F add9
    [48,55,64,71],   // C maj7
    [43,50,59,67]    // G sus
  ];
  /* a tiny motif for the melodic moods (scale degrees over the chord) */
  const MOTIF = [0, 2, 1, 3, 2, 4, 3, 2];

  /* ---------- the graph ---------- */
  function build() {
    if (A.ctx) return;
    const Ctx = w.AudioContext || w.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    A.ctx = ctx;

    const master = ctx.createGain();
    master.gain.value = 0.0001;
    const tone = ctx.createBiquadFilter();
    tone.type = "lowpass"; tone.frequency.value = 1700; tone.Q.value = 0.25;
    const limiter = ctx.createDynamicsCompressor();
    limiter.threshold.value = -10; limiter.knee.value = 10;
    limiter.ratio.value = 6; limiter.attack.value = 0.004; limiter.release.value = 0.24;
    tone.connect(master).connect(limiter).connect(ctx.destination);

    /* a soft space: feedback delay tucked under everything */
    const delay = ctx.createDelay(1);
    delay.delayTime.value = 0.31;
    const fb = ctx.createGain(); fb.gain.value = 0.34;
    const dampen = ctx.createBiquadFilter();
    dampen.type = "lowpass"; dampen.frequency.value = 2400;
    const wet = ctx.createGain(); wet.gain.value = 0.24;
    delay.connect(dampen).connect(fb).connect(delay);
    delay.connect(wet).connect(tone);
    A.delay = delay;

    /* night air: filtered noise, barely there */
    const nLen = ctx.sampleRate * 2;
    const nBuf = ctx.createBuffer(1, nLen, ctx.sampleRate);
    const nd = nBuf.getChannelData(0);
    for (let i = 0; i < nLen; i++) nd[i] = (Math.random() * 2 - 1) * 0.5;
    const air = ctx.createBufferSource();
    air.buffer = nBuf; air.loop = true;
    const airF = ctx.createBiquadFilter();
    airF.type = "bandpass"; airF.frequency.value = 480; airF.Q.value = 0.6;
    const airG = ctx.createGain(); airG.gain.value = 0;
    air.connect(airF).connect(airG).connect(tone);
    air.start();
    A.airG = airG;

    A.master = master; A.tone = tone;
    A.ready = true;
  }

  /* ---------- voices ---------- */
  function padChord(t, midi, dur) {
    const ctx = A.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(0.05, t + dur * 0.35);
    g.gain.setValueAtTime(0.05, t + dur * 0.7);
    g.gain.linearRampToValueAtTime(0.0001, t + dur * 1.05);
    g.connect(A.tone);
    if (A.delay) g.connect(A.delay);
    midi.forEach(m => {
      [-2.5, 2.5].forEach(cents => {
        const o = ctx.createOscillator();
        o.type = "triangle";
        o.frequency.value = N(m) * Math.pow(2, cents / 1200);
        o.connect(g);
        o.start(t); o.stop(t + dur * 1.1);
      });
    });
  }

  function celesta(t, midi, vel) {
    const ctx = A.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vel, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.35);
    g.connect(A.tone);
    if (A.delay) g.connect(A.delay);
    [1, 3].forEach((h, i) => {
      const o = ctx.createOscillator();
      o.type = "sine";
      o.frequency.value = N(midi) * h;
      const hg = ctx.createGain();
      hg.gain.value = i === 0 ? 1 : 0.22;
      o.connect(hg).connect(g);
      o.start(t); o.stop(t + 1.5);
    });
  }

  function bell(t, midi) {
    const ctx = A.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.05, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 2.4);
    g.connect(A.tone);
    if (A.delay) g.connect(A.delay);
    const o = ctx.createOscillator();
    o.type = "sine"; o.frequency.value = N(midi + 24);
    o.connect(g); o.start(t); o.stop(t + 2.5);
  }

  /* ---------- the scheduler ---------- */
  function currentChord() {
    const M = MOODS[A.mood] || MOODS.night;
    if (A.mood === "fall") return FILM_CHORDS[A.moodArg % FILM_CHORDS.length];
    return M.chords[A.bar % M.chords.length];
  }

  function pluck(t, midi, vel) {
    const ctx = A.ctx;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(vel, t + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    const o = ctx.createOscillator();
    o.type = "triangle";
    o.frequency.value = N(midi);
    g.connect(A.tone);
    if (A.delay) g.connect(A.delay);
    o.connect(g);
    o.start(t); o.stop(t + 0.55);
  }

  function heartbeat(t) {
    const ctx = A.ctx;
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(58, t);
    o.frequency.exponentialRampToValueAtTime(38, t + 0.18);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.12, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.42);
    o.connect(g).connect(A.tone);
    o.start(t); o.stop(t + 0.45);
  }

  const K = m => m + (MOODS[A.mood] ? MOODS[A.mood].key : 0);   // key offset

  function schedule() {
    const ctx = A.ctx;
    if (!ctx || !A.enabled) return;
    const ahead = ctx.currentTime + 0.3;
    while (A.nextT < ahead) {
      const t = A.nextT, s = A.step;
      const M = MOODS[A.mood] || MOODS.night;
      const EIGHTH = 60 / M.bpm / 2;                 // tempo can change per scene
      const perBar = M.sig === 3 ? 6 : 8;            // 3/4 or 4/4
      const ch = () => (A.mood === "fall"
        ? FILM_CHORDS[A.moodArg % FILM_CHORDS.length]
        : M.chords[A.bar % M.chords.length]).map(K);

      if (s % perBar === 0) {
        /* bar 1: the pad re-voices, and the bass plucks the root */
        padChord(t, ch(), perBar * EIGHTH * 1.02);
        if (M.pluck > 0) pluck(t, ch()[0] - 12, 0.09 * M.pluck);
        if (M.heart && s % (perBar * 2) === 0) heartbeat(t);
        A.bar++;
      } else if (M.sig === 3 && (s % perBar === 2 || s % perBar === 4)) {
        /* waltz beats 2 & 3: soft plucked chord tones */
        if (M.pluck > 0) pluck(t, ch()[1 + (s % perBar === 4 ? 1 : 0)], 0.05 * M.pluck);
      } else if (M.sig === 4 && M.pluck > 0 && (s % 8 === 4)) {
        pluck(t, ch()[(A.bar + 1) % ch().length], 0.05 * M.pluck);
      }

      /* climbing the stairs: the melody rises with the camera */
      if (A.climb > 0.01 && s % 2 === 0) {
        const c2 = ch();
        const deg = Math.min(c2.length - 1, Math.floor(A.climb * c2.length));
        celesta(t, c2[deg] + 12 + (A.climb > 0.6 ? 12 : 0), 0.11);
      } else if (M.box > 0 && (s % 2 === 0 || M.box >= 1)) {
        const c2 = ch();
        if (M.box >= 0.9 && s % 4 === 0) {
          const k = MOTIF[(A.bar * 2 + (s >> 2)) % MOTIF.length];
          celesta(t, c2[k % c2.length] + 12, 0.12 * M.box + 0.04);
        } else if (Math.random() < 0.2 * M.box + 0.04) {
          celesta(t, c2[(s * 7 + A.bar) % c2.length] + 12 * (1 + ((s >> 3) % 2)), 0.07);
        }
      }

      /* bells for the sky */
      if (M.bells > 0 && s % 16 === 12 && Math.random() < M.bells) {
        bell(t, ch()[0]);
      }

      A.step++;
      A.nextT += EIGHTH;
    }
  }

  function startClock() {
    if (A.timer) return;
    A.nextT = A.ctx.currentTime + 0.1;
    A.timer = setInterval(schedule, 110);
  }

  /* ---------- zone logic (scene-aware, same spine as before) ---------- */
  let ZONES = null;
  function buildZones() {
    ZONES = [];
    const yOf = (el, lead) => (el ? el.offsetTop - innerHeight * (lead || 0.5) : Infinity);
    ZONES.push({ y0: 0, m: "night" });
    const corridor = document.getElementById("corridor");
    const celebration = document.getElementById("celebration");
    const house = document.getElementById("house");
    const finaleSec = document.getElementById("finale");
    const yearsSec = document.getElementById("years");
    const roadSec = document.getElementById("road");
    if (yearsSec) ZONES.push({ y0: yOf(yearsSec, 0.5), m: "years" });
    if (corridor) ZONES.push({ y0: yOf(corridor, 0.5), m: "fall" });
    if (roadSec) ZONES.push({ y0: yOf(roadSec, 0.5), m: "road" });
    if (celebration) ZONES.push({ y0: yOf(celebration, 0.4), m: "warm" });
    if (house) ZONES.push({ y0: yOf(house, 0.3), m: "approach" });
    ZONES.houseST = null; ZONES.corridorST = null;
    try {
      const all = window.ScrollTrigger.getAll();
      const hst = all.filter(s => s.trigger === house && s.end - s.start > 5000)[0];
      if (hst) ZONES.houseST = hst;
      const cst = all.filter(s => s.trigger === corridor && s.end - s.start > 3000)[0];
      if (cst) ZONES.corridorST = cst;
    } catch (e) { /* rebuilt on demand */ }
    if (finaleSec) ZONES.push({ y0: yOf(finaleSec, 0.5), m: "outro" });
    ZONES.sort((a, b) => a.y0 - b.y0);
  }
  let zrt; addEventListener("resize", () => {
    clearTimeout(zrt); zrt = setTimeout(() => { ZONES = null; }, 400);
  }, { passive: true });

  function setProgress(p) {
    A.progress = p;
    if (!A.enabled || !A.ctx) return;
    if (!ZONES) buildZones();
    const y = p * Math.max(1, document.body.scrollHeight - innerHeight);
    let mood = "night", arg = 0, climb = 0;
    for (let i = 0; i < ZONES.length; i++) {
      if (y >= ZONES[i].y0) mood = ZONES[i].m; else break;
    }
    /* the film: the chord follows the photograph on screen */
    const cst = ZONES.corridorST;
    if (cst && mood === "fall" && y >= cst.start && y <= cst.end) {
      arg = Math.max(0, Math.min(7, Math.floor((y - cst.start) / (cst.end - cst.start) * 8)));
    }
    /* the house: sub-zones by camera key */
    const st = ZONES.houseST;
    if (st && y >= st.start && y <= st.end && mood === "approach") {
      const hp = (y - st.start) / (st.end - st.start);
      const tAt = (window.__house && window.__house.app && window.__house.app.tAt) || null;
      if (tAt) {
        if (hp >= tAt("roofcake") - 0.001) mood = "finale";
        else if (hp >= tAt("terrace")) mood = "rooftop";
        else if (hp >= tAt("emerging")) mood = "darkroom";
        else if (hp >= tAt("wishfoot") && hp < tAt("climb6")) mood = "wishes";
        else if (hp >= tAt("cake-wish") && hp < tAt("cake-blow")) mood = "wish";
        else if (hp >= tAt("cake-blow") && hp < tAt("gifts")) mood = "cut";
        else if (hp >= tAt("threshold")) mood = "interior";
        /* the stairs sing while you climb them */
        if (hp >= tAt("stairfoot") && hp <= tAt("stairtop")) {
          climb = (hp - tAt("stairfoot")) / (tAt("stairtop") - tAt("stairfoot"));
        } else if (hp >= tAt("roofstair") && hp <= tAt("emerging")) {
          climb = (hp - tAt("roofstair")) / (tAt("emerging") - tAt("roofstair"));
        }
      }
    }
    A.mood = mood; A.moodArg = arg; A.climb = climb;
    const M = MOODS[mood] || MOODS.night;
    A.tone.frequency.setTargetAtTime(M.lp, A.ctx.currentTime, 0.7);
    A.master.gain.setTargetAtTime(VOL * M.g, A.ctx.currentTime, 0.9);
    if (A.airG) A.airG.gain.setTargetAtTime(0.012 * (M.air || 0), A.ctx.currentTime, 1.2);
  }

  /* ---------- public ---------- */
  function start() {
    /* called from the start gate — a real gesture, so playback may begin */
    if (!A.supported) return Promise.resolve();
    build();
    if (!A.ready) return Promise.resolve();
    if (A.ctx.state === "suspended") A.ctx.resume();
    A.enabled = true;
    const M = MOODS[A.mood] || MOODS.night;
    A.master.gain.setTargetAtTime(VOL * M.g, A.ctx.currentTime, 0.8);
    startClock();
    setProgress(A.progress);
    return Promise.resolve();
  }
  function toggle() {
    if (!A.ready) { start(); return false; }
    if (A.enabled) {
      A.enabled = false;
      A.master.gain.setTargetAtTime(0.0001, A.ctx.currentTime, 0.3);
      clearInterval(A.timer); A.timer = null;
    } else {
      A.enabled = true;
      if (A.ctx.state === "suspended") A.ctx.resume();
      A.nextT = A.ctx.currentTime + 0.1;
      A.master.gain.setTargetAtTime(VOL * (MOODS[A.mood] || MOODS.night).g, A.ctx.currentTime, 0.6);
      startClock();
      setProgress(A.progress);
    }
    return A.enabled;
  }

  /** a short, clean bell for the moment the candles go out */
  function wishChime() {
    if (!A.ctx || !A.enabled) return;
    const ctx = A.ctx, t = ctx.currentTime;
    const bus = ctx.createGain(); bus.gain.value = 0.9;
    bus.connect(A.tone); if (A.delay) bus.connect(A.delay);
    [880, 1318.5, 1760].forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, t + i * 0.06);
      g.gain.exponentialRampToValueAtTime(0.14 / (i + 1), t + i * 0.06 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.06 + 2.2);
      o.connect(g).connect(bus);
      o.start(t + i * 0.06); o.stop(t + i * 0.06 + 2.4);
    });
    setTimeout(() => bus.disconnect(), 3000);
  }

  /** a soft firework thump + sparkle, used on the rooftop */
  function pop(strength = 1) {
    if (!A.ctx || !A.enabled) return;
    const ctx = A.ctx, t = ctx.currentTime;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.08 * strength, t + 0.015);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.9);
    const noise = ctx.createBufferSource();
    const len = Math.floor(ctx.sampleRate * 0.9);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6);
    noise.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass"; bp.frequency.value = 900; bp.Q.value = 0.8;
    noise.connect(bp).connect(g).connect(A.tone);
    noise.start(t);
    const o = ctx.createOscillator(), og = ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(180, t);
    o.frequency.exponentialRampToValueAtTime(60, t + 0.4);
    og.gain.setValueAtTime(0.09 * strength, t);
    og.gain.exponentialRampToValueAtTime(0.0001, t + 0.5);
    o.connect(og).connect(A.tone);
    o.start(t); o.stop(t + 0.55);
  }

  /** a tiny mechanical tick — the projector changing slides */
  function tick() {
    if (!A.ctx || !A.enabled) return;
    const ctx = A.ctx, t = ctx.currentTime;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.05, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    const noise = ctx.createBufferSource();
    const len = Math.floor(ctx.sampleRate * 0.05);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 4);
    noise.buffer = buf;
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass"; hp.frequency.value = 2600;
    noise.connect(hp).connect(g).connect(A.tone);
    noise.start(t);
  }

  w.BdayAudio = {
    get supported() { return A.supported; },
    get enabled() { return A.enabled; },
    get ready() { return A.ready; },
    get mood() { return A.mood; },
    get chord() { return A.mood === "fall" ? A.moodArg : -1; },
    start, toggle, setProgress, wishChime, pop,
    // the projector click on every slide change of the memory film
    // (scenes.js calls this — it was never exported, so the tick never played)
    tick
  };
})(window);
