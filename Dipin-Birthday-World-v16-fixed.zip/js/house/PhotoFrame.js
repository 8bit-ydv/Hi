/* =============================================================
   PHOTO FRAME  —  the flicker fix lives here
   -------------------------------------------------------------
   Root causes of the old blinking, all addressed:
     • z-fighting        -> photo sits a real 4mm in FRONT of the mat,
                            mat 4mm in front of the backing. No coplanar faces.
     • duplicate meshes  -> one mesh per photo, built once, never rebuilt.
     • texture recreation-> TEX_CACHE guarantees ONE THREE.Texture per file,
                            shared by every frame that uses it.
     • transparent sort  -> photo/mat/backing are all fully OPAQUE
                            (transparent:false, depthWrite:true). Nothing to sort.
     • animated opacity  -> frames never tween opacity. They fade via the
                            scene, not per-material.
     • camera clipping   -> frames are never thinner than 2cm.
     • re-render churn   -> geometry + material are created once and reused.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { roundedBox } from "./geometry.js";

/* ---- one texture per file, forever ---- */
const TEX_CACHE = new Map();
const loader = new THREE.TextureLoader();

/* ---- the photographs' own aspect ratios (height / width) ----
   Most prints are 3:4 (1.333), but three were shot/cropped differently.
   A frame that forces every photo into 4:3 quietly stretches those
   three by 7–11 % — real faces, visibly squeezed. Frames now honour
   the true ratio, so no photograph is ever stretched or squashed. */
export const PHOTO_RATIOS = {
  p01: 1.194, p16: 1.370, p17: 1.237
};
const PHOTO_ID = url => {
  // accepts "p01", "p01_sm", "p01.webp", "p01_sm.webp"
  const m = /(p\d{2})(?:_sm)?(?:\.(?:webp|jpe?g|png))?$/i.exec(String(url || "").split("/").pop());
  return m ? m[1] : null;
};
export function PHOTO_RATIO(url) {
  const id = PHOTO_ID(url);
  return (id && PHOTO_RATIOS[id]) || 1.333;
}

export function getPhotoTexture(url, anisotropy = 4) {
  if (TEX_CACHE.has(url)) return TEX_CACHE.get(url);
  const t = loader.load(url);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = anisotropy;
  t.generateMipmaps = true;
  t.minFilter = THREE.LinearMipmapLinearFilter;
  t.magFilter = THREE.LinearFilter;
  t.needsUpdate = true;
  TEX_CACHE.set(url, t);
  return t;
}

export function preloadPhotos(urls, anisotropy = 4) {
  urls.forEach(u => getPhotoTexture(u, anisotropy));
}

/* ---- shared geometry, built lazily per unique size ---- */
const GEO_CACHE = new Map();
function cachedGeo(key, build) {
  if (!GEO_CACHE.has(key)) GEO_CACHE.set(key, build());
  return GEO_CACHE.get(key);
}

// deliberate, generous depth separation (metres)
const D_BACK = 0.028;   // backing slab thickness
const D_MAT  = 0.006;   // mat sits this far in front of backing face
const D_PIC  = 0.005;   // photo sits this far in front of the mat

/**
 * Build a framed photograph.
 * @param {string} url        texture url
 * @param {object} M          material library
 * @param {object} o          { width, ratio, frame, mat, anisotropy, glass }
 * @returns {THREE.Group}     +Z is the viewing direction
 */
export function makePhotoFrame(url, M, o = {}) {
  const {
    width = 0.9,
    frame = "frameWood",
    matWidth = 0.055,
    anisotropy = 4,
    glass = false
  } = o;
  // Every frame honours the photograph's own aspect ratio (height/width):
  // the old code forced every print into ~1.33, stretching p01/p16/p17.
  const ratio = PHOTO_RATIO(url);

  const picW = width;
  const picH = width * ratio;
  const matW = picW + matWidth * 2;
  const matH = picH + matWidth * 2;
  const frW  = matW + 0.05;
  const frH  = matH + 0.05;

  const g = new THREE.Group();

  // --- frame moulding: four bevelled bars, no face shares a plane with art ---
  const barGeoH = cachedGeo(`fh${frW.toFixed(3)}`, () => roundedBox(frW, 0.055, 0.05, 0.014, 1));
  const barGeoV = cachedGeo(`fv${frH.toFixed(3)}`, () => roundedBox(0.055, frH, 0.05, 0.014, 1));
  const fm = M[frame] || M.frameWood;
  const top = new THREE.Mesh(barGeoH, fm);
  const bot = new THREE.Mesh(barGeoH, fm);
  const lef = new THREE.Mesh(barGeoV, fm);
  const rig = new THREE.Mesh(barGeoV, fm);
  top.position.set(0,  frH / 2 - 0.0275, 0.006);
  bot.position.set(0, -frH / 2 + 0.0275, 0.006);
  lef.position.set(-frW / 2 + 0.0275, 0, 0.006);
  rig.position.set( frW / 2 - 0.0275, 0, 0.006);
  [top, bot, lef, rig].forEach(m => { m.castShadow = true; g.add(m); });

  // --- backing slab (opaque, gives the frame real thickness) ---
  const backing = new THREE.Mesh(
    cachedGeo(`bk${matW.toFixed(3)}x${matH.toFixed(3)}`,
      () => roundedBox(matW + 0.01, matH + 0.01, D_BACK, 0.008, 1)),
    M.backing
  );
  backing.position.z = -D_BACK / 2;
  backing.castShadow = true;
  backing.receiveShadow = true;
  g.add(backing);

  // --- mat board (opaque plane, clearly in front of the backing) ---
  const mat = new THREE.Mesh(
    cachedGeo(`mt${matW.toFixed(3)}x${matH.toFixed(3)}`, () => new THREE.PlaneGeometry(matW, matH)),
    M.mat
  );
  mat.position.z = D_MAT;
  mat.receiveShadow = true;
  g.add(mat);

  // --- the photograph: OPAQUE, depth-written, well clear of the mat ---
  const tex = getPhotoTexture(url, anisotropy);
  const picMat = new THREE.MeshStandardMaterial({
    map: tex,
    roughness: 0.66,
    metalness: 0,
    transparent: false,     // <- never alpha-sorted
    depthWrite: true,
    depthTest: true,
    side: THREE.FrontSide,
    toneMapped: true
  });
  const pic = new THREE.Mesh(
    cachedGeo(`pc${picW.toFixed(3)}x${picH.toFixed(3)}`, () => new THREE.PlaneGeometry(picW, picH)),
    picMat
  );
  pic.position.z = D_MAT + D_PIC;
  pic.receiveShadow = true;
  // stop the renderer from ever reordering this against the mat
  pic.renderOrder = 1;
  g.add(pic);

  // --- optional glass: additive sheen, no depth write, cannot fight the photo ---
  if (glass) {
    const gl = new THREE.Mesh(
      cachedGeo(`gl${matW.toFixed(3)}x${matH.toFixed(3)}`, () => new THREE.PlaneGeometry(matW, matH)),
      new THREE.MeshBasicMaterial({
        color: 0xbcd4ea, transparent: true, opacity: 0.055,
        depthWrite: false, blending: THREE.AdditiveBlending
      })
    );
    gl.position.z = D_MAT + D_PIC + 0.008;
    gl.renderOrder = 2;
    g.add(gl);
  }

  g.userData.size = { w: frW, h: frH };
  g.userData.photo = pic;
  return g;
}

/** Frame standing on a surface, with a little easel foot. */
export function makeStandingFrame(url, M, o = {}) {
  const g = makePhotoFrame(url, M, { frame: "frameGold", ...o });
  const h = g.userData.size.h;
  const foot = new THREE.Mesh(roundedBox(0.05, h * 0.62, 0.02, 0.008, 1), M.frameWood);
  foot.position.set(0, -h * 0.16, -0.09);
  foot.rotation.x = 0.34;
  g.add(foot);
  return g;
}

export function disposePhotoCaches() {
  TEX_CACHE.forEach(t => t.dispose());
  TEX_CACHE.clear();
  GEO_CACHE.forEach(g => g.dispose());
  GEO_CACHE.clear();
}
