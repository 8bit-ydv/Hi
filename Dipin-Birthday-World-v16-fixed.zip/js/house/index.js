/* =============================================================
   SCENE VI ENTRY
   Wires the WebGL house to the page: scroll progress, hotspots,
   captions and visibility.

   Captions and hotspots are NOT spaced evenly across the scroll —
   they are pinned to the camera keys they belong to (by tag), so a
   line of text is on screen for exactly as long as the shot it
   describes. That is what keeps picture and words in step.
   ============================================================= */
import { createHouseScene } from "./HouseScene.js";
import * as THREE from "../../assets/vendor/three.module.min.js";
import { buildIntro, createIntroTimeline } from "./Intro.js";

export function mountHouse() {
  const canvas = document.getElementById("houseCanvas");
  const sec = document.getElementById("house");
  if (!canvas || !sec) return null;

  const C = window.BDAY_CONFIG;
  const HOUSE = C.house;
  const mobile = matchMedia("(max-width: 820px)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  let app;
  try {
    app = createHouseScene(canvas, { mobile, reduce });
  } catch (err) {
    console.warn("[house] WebGL unavailable:", err);
    sec.classList.add("no-webgl");
    return null;
  }

  const tAt = app.tAt;

  /* ---------------- Ekanth's intro ---------------- */
  const intro = buildIntro(sec, C);
  const introTl = createIntroTimeline(intro, gsap);

  /* ---------------- the hidden memory (easter egg) ----------------
     One small gold frame on the upper-floor reading table. Tap it and
     a cinematic overlay opens with the hero photograph. Entirely
     optional — the journey never depends on it. */
  let eggOverlay = null;
  function closeEgg() {
    if (!eggOverlay) return;
    eggOverlay.classList.remove("open");
    setTimeout(() => { if (eggOverlay) eggOverlay.remove(); eggOverlay = null; }, 480);
  }
  function openEgg() {
    if (eggOverlay) return;
    const hero = (C.photos && C.photos.hero) || "p17";
    eggOverlay = document.createElement("div");
    eggOverlay.className = "egg-overlay";
    eggOverlay.innerHTML =
      `<div class="egg-scrim"></div>` +
      `<figure class="egg-card">` +
        `<img src="${C.paths.photos + hero}.webp" alt="One more memory">` +
        `<figcaption>` +
          `<p class="egg-title">You found one more memory.</p>` +
          `<p class="egg-sub">The best ones were never on the wall.</p>` +
          `<button type="button" class="egg-btn">keep it</button>` +
        `</figcaption>` +
      `</figure>`;
    sec.appendChild(eggOverlay);
    requestAnimationFrame(() => eggOverlay.classList.add("open"));
    eggOverlay.querySelector(".egg-btn").addEventListener("click", closeEgg);
    eggOverlay.querySelector(".egg-scrim").addEventListener("click", closeEgg);
    addEventListener("keydown", function onEsc(e) {
      if (e.key === "Escape") { closeEgg(); removeEventListener("keydown", onEsc); }
    });
    if (window.BdayAudio && BdayAudio.enabled && BdayAudio.wishChime) BdayAudio.wishChime();
  }
  if (app.easterEgg) {
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const hitMesh = app.easterEgg.hit;
    const inEggRange = () => progress > tAt("gallery") - 0.02 && progress < tAt("roofstair") + 0.02;
    function eggAt(cx, cy) {
      if (!inEggRange() || !app.easterEgg) return false;
      ndc.set((cx / innerWidth) * 2 - 1, -(cy / innerHeight) * 2 + 1);
      ray.setFromCamera(ndc, app.camera);
      return ray.intersectObject(hitMesh, false).length > 0;
    }
    canvas.addEventListener("click", e => { if (eggAt(e.clientX, e.clientY)) openEgg(); });
    // a soft pointer cursor while hovering the frame (throttled)
    let eggHoverT = 0;
    addEventListener("pointermove", e => {
      const now = performance.now();
      if (now - eggHoverT < 140) return;
      eggHoverT = now;
      canvas.style.cursor = eggAt(e.clientX, e.clientY) ? "pointer" : "";
    }, { passive: true });
  }

  /* ---------------- hotspots ---------------- */
  const layer = document.getElementById("houseHotspots");
  const tmp = new THREE.Vector3();
  const hotspots = HOUSE.hotspots.map(h => {
    const el = document.createElement("button");
    el.className = "hotspot";
    el.type = "button";
    el.innerHTML =
      `<span class="hs-dot"></span>` +
      `<span class="hs-card"><b>${h.title}</b><i>${h.text}</i></span>`;
    el.setAttribute("aria-label", h.title);
    el.addEventListener("click", e => {
      e.stopPropagation();
      const wasOpen = el.classList.contains("open");
      layer.querySelectorAll(".hotspot.open").forEach(o => o.classList.remove("open"));
      if (!wasOpen) el.classList.add("open");
    });
    layer.appendChild(el);
    const show = h.show || [tAt(h.from), tAt(h.to)];
    return { el, pos: new THREE.Vector3(...h.at), show, visible: false };
  });

  /* ---------------- captions ----------------
     One timeline, built from the config: the ordinary captions plus
     the cake ceremony beats, each with a real start/end taken from
     the camera keys. Exactly one can be active at any scroll point. */
  const capWrap = document.getElementById("houseCaptions");
  const windows = [];
  (HOUSE.captions || []).forEach(c => {
    if (!c.text) return;
    windows.push({ t0: tAt(c.from), t1: tAt(c.to), text: c.text, ceremony: false });
  });
  ((HOUSE.cake && HOUSE.cake.beats) || []).forEach(b => {
    windows.push({ t0: tAt(b.from), t1: tAt(b.to), text: b.text, ceremony: true });
  });
  windows.sort((a, b) => a.t0 - b.t0);

  const capEl = document.createElement("p");
  capEl.className = "hcap";
  capWrap.appendChild(capEl);
  let activeCap = -1;

  function findWindow(p) {
    for (let i = 0; i < windows.length; i++) {
      const w = windows[i];
      if (p >= w.t0 && p < w.t1) return i;
    }
    return -1;
  }

  function setCaption(i) {
    if (i === activeCap) return;
    activeCap = i;
    const w = windows[i];
    gsap.killTweensOf(capEl);
    gsap.to(capEl, {
      opacity: 0, y: -12, duration: 0.28, ease: "power2.in",
      onComplete: () => {
        if (!w) { capEl.textContent = ""; return; }
        capEl.textContent = w.text;
        capEl.classList.toggle("hcap-ceremony", !!w.ceremony);
        gsap.fromTo(capEl, { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.55, ease: "power2.out" });
      }
    });
  }

  /* ---------------- scroll + pointer ---------------- */
  const SCROLL_LEN = mobile ? 7800 : 11200;  // px of scroll for the whole journey (4 storeys + darkroom)
  let visible = false;
  let progress = 0;

  if (!reduce) {
    addEventListener("pointermove", e => {
      app.setPointer((e.clientX / innerWidth - 0.5) * 2, (e.clientY / innerHeight - 0.5) * 2);
    }, { passive: true });
  }

  gsap.to({ v: 0 }, {
    v: 1, ease: "none",
    scrollTrigger: {
      trigger: sec,
      start: "top top",
      end: "+=" + SCROLL_LEN,
      scrub: reduce ? true : 0.85,
      pin: sec.querySelector(".pin"),
      anticipatePin: 1,
      onUpdate: self => {
        progress = self.progress;
        app.setProgress(progress);
        window.dispatchEvent(new CustomEvent("house:progress", { detail: progress }));

        /* ---- Ekanth's intro plays across the opening stretch ---- */
        const introEnd = app.introEnd ?? 0.14;
        if (progress <= introEnd + 0.02) {
          introTl.progress(Math.min(1, progress / introEnd));
          intro.root.style.display = "";
        } else if (intro.root.style.display !== "none") {
          introTl.progress(1);
          intro.root.style.display = "none";
        }

        /* ---- captions ---- */
        setCaption(progress < introEnd ? -1 : findWindow(progress));
      }
    }
  });

  // the section headline steps aside immediately so the intro cards own the frame
  gsap.to(".house-head", {
    opacity: 0, y: -34, filter: "blur(8px)", ease: "none",
    scrollTrigger: { trigger: sec, start: "top top", end: "+=" + SCROLL_LEN * 0.03, scrub: true }
  });
  gsap.to(".house-hint", {
    opacity: 0, ease: "none",
    scrollTrigger: { trigger: sec, start: "top top", end: "+=" + SCROLL_LEN * 0.03, scrub: true }
  });

  /* ---------------- render loop ---------------- */
  gsap.ticker.add(() => {
    if (document.hidden) return;
    const r = sec.getBoundingClientRect();
    const on = r.top < innerHeight * 1.1 && r.bottom > -innerHeight * 0.1;
    if (on !== visible) {
      visible = on;
      canvas.style.opacity = on ? "1" : "0";
    }
    if (!visible) return;

    app.render();

    // project hotspots
    const cam = app.camera;
    for (let i = 0; i < hotspots.length; i++) {
      const h = hotspots[i];
      const inRange = progress >= h.show[0] && progress <= h.show[1];
      if (!inRange) {
        if (h.visible) {
          h.visible = false;
          h.el.style.opacity = "0";
          h.el.style.pointerEvents = "none";
          h.el.classList.remove("open");
        }
        continue;
      }
      tmp.copy(h.pos).project(cam);
      const on = tmp.z < 1 && Math.abs(tmp.x) < 1.25 && Math.abs(tmp.y) < 1.25;
      if (on !== h.visible) {
        h.visible = on;
        h.el.style.opacity = on ? "1" : "0";
        h.el.style.pointerEvents = on ? "auto" : "none";
        if (!on) h.el.classList.remove("open");
      }
      if (on) {
        h.el.style.transform = `translate(-50%,-50%) translate(${(tmp.x * .5 + .5) * innerWidth}px, ${(-tmp.y * .5 + .5) * innerHeight}px)`;
      }
    }
  });

  let rt;
  addEventListener("resize", () => {
    clearTimeout(rt);
    rt = setTimeout(() => app.resize(), 180);
  }, { passive: true });

  return { app, SCROLL_LEN };
}
