/* =============================================================
   INTERIORS
   Ground floor  — celebration room (cake, gifts, sofa, banner)
   Staircase     — ascending memory gallery
   Upper floor   — memory wall + hallway frames + reading nook
   Rooftop       — terrace finale (lights, balloons, reveal)
   Photos are distributed across all four, never repeated on one wall.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { DIM } from "./Architecture.js";
import { roundedBox, textTexture, glowSprite } from "./geometry.js";
import { makePhotoFrame, makeStandingFrame, getPhotoTexture } from "./PhotoFrame.js";
import {
  makeCake, makeGiftPile, makeBalloon, makeBalloonCluster, makeStringLights,
  makeBanner, makeTable, makeSofa, makeLamp, makePendantLight, makePlant,
  makeRug, makeShelf, makeCandleStick,
  makeBookshelf, makeChair, makeArmchair, makeBookStack,
  makeDanceFloor, makeDiscoBall, makeDJBooth, makeSpeaker, makeBunting
} from "./Props.js";

const C = () => window.BDAY_CONFIG;
const P = () => window.BDAY_CONFIG.paths.photos;
const HP = () => window.BDAY_CONFIG.house.photos;

export function buildInteriors(scene, M, quality) {
  const { W, D, T, H0, F1, H1, FW, F2, STAIR_X } = DIM;
  const anim = {                    // everything the render loop animates
    flames: [], halos: [], bulbs: [], balloons: [], flags: [],
    lights: [], sprites: []
  };
  const lights = [];
  const root = new THREE.Group();
  scene.add(root);

  const iw = W - T * 2.1, id = D - T * 2.1;   // interior clear dims
  const G = 0.63;                              // ground floor walking level
  const U = F1 + 0.08;                         // upper floor walking level
  const R = F2 + 0.11;                         // roof deck level
  const WL = FW + 0.08;                        // the room of wishes, deck top

  const addLight = (l, meta = {}) => { root.add(l); lights.push(Object.assign(l, { userData: meta })); return l; };

  /* Photos must always be clearly visible, but one PointLight per frame
     is far too expensive. Instead the photo material gets a gentle
     emissive lift from its own texture — zero extra lights, and it can
     never flicker because nothing about it is animated. */
  const liftPhoto = (frame, amount = 0.26) => {
    const pic = frame.userData.photo;
    if (!pic) return;
    pic.material.emissive = new THREE.Color(0xffffff);
    pic.material.emissiveMap = pic.material.map;
    pic.material.emissiveIntensity = amount;
    pic.material.needsUpdate = true;
  };

  /* =====================================================
     THE PORCH LIGHT — under the portico, off until the
     approach sequence turns it on (see HouseScene). It is
     also the warm spill that "opens" with the front door.
     ===================================================== */
  {
    // NOTE: no real PointLight here any more. A light switching on exactly
    // at the door changed the scene's light count mid-approach, which made
    // three.js recompile shaders — the "lag" when the camera reached the
    // door. The lantern's bulb + halo sprite carry the look instead, and
    // the warm spill comes from the room light through the opening door.
    const porch = { position: new THREE.Vector3(0, 4.18, D / 2 + 1.35), intensity: 0, visible: true };
    // a small brass lantern so the light has a body
    const fix = new THREE.Group();
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.16, 0.14, 8), M.brassDark);
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.11, 0.2, 8),
      new THREE.MeshStandardMaterial({ color: 0xffd9a4, emissive: 0xffb063, emissiveIntensity: 0.35, roughness: 0.4 }));
    body.position.y = -0.14;
    fix.add(cap, body);
    fix.position.set(0, 4.34, D / 2 + 1.35);
    root.add(fix);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowSprite("rgb(255,200,130)"), color: 0xffc27d, transparent: true,
      opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    halo.scale.setScalar(0.85);
    halo.position.set(0, 4.2, D / 2 + 1.35);
    root.add(halo);
    anim.porch = { light: porch, halo, bulb: body };
  }

  /* =====================================================
     GROUND FLOOR — the celebration room
     ===================================================== */
  {
    const rug = makeRug(M, 5.0, 3.6);
    rug.position.set(1.4, G + 0.02, 0.6);
    root.add(rug);

    // --- cake on a round table, dead centre of attention ---
    const cakeTable = makeTable(M, 1.9, 1.9, 0.82, true);
    cakeTable.position.set(0.4, G, -1.4);
    root.add(cakeTable);

    const cloth = new THREE.Mesh(
      new THREE.CylinderGeometry(1.02, 1.16, 0.5, 32, 1, true),
      new THREE.MeshStandardMaterial({ color: 0xf3e2cb, roughness: 0.95, side: THREE.DoubleSide }));
    cloth.position.set(0.4, G + 0.58, -1.4);
    root.add(cloth);

    const cake = makeCake(M, { numeral: String(C().age ?? 20), scale: 1.15, tiers: 3, candles: 8 });
    cake.position.set(0.4, G + 0.82, -1.4);
    root.add(cake);
    // the ceremony owns these flames/halos, so they are NOT added to the
    // generic idle animation lists (that would fight the blow-out)
    anim.cake = cake;
    // the hero light of the whole house
    const cakeLight = addLight(new THREE.PointLight(0xffb264, 9, 7.5, 2), { kind: "cake", zone: "interior" });
    cakeLight.position.set(0.4, G + 2.0, -1.4);
    anim.lights.push({ light: cakeLight, base: 9, amp: 1.5, speed: 3.4 });

    // plates + candlesticks on the table
    [[-0.62, -0.4], [0.62, -0.3]].forEach(([dx, dz]) => {
      const cs = makeCandleStick(M, 0.4);
      cs.position.set(0.4 + dx, G + 0.82, -1.4 + dz);
      root.add(cs);
      anim.flames.push(cs.userData.flame);
      anim.halos.push(cs.userData.halo);
    });

    // --- gifts around the table ---
    const gifts = makeGiftPile(M, 7, 1.3, 0);
    gifts.position.set(-1.7, G, 0.7);
    root.add(gifts);
    const gifts2 = makeGiftPile(M, 4, 1.1, 3);
    gifts2.position.set(3.6, G, -2.2);
    root.add(gifts2);
    // a light of its own, so the gift beat can bring them up out of the dark
    const giftLight = addLight(new THREE.PointLight(0xffd0a0, 0, 7, 2), { kind: "gift", zone: "interior" });
    giftLight.position.set(-1.7, G + 1.5, 1.3);
    anim.giftLight = giftLight;

    // --- seating ---
    const sofa = makeSofa(M, 3.0);
    sofa.position.set(2.6, G, 2.6);
    sofa.rotation.y = -0.42;
    root.add(sofa);

    const coffee = makeTable(M, 1.3, 0.8, 0.44);
    coffee.position.set(1.4, G, 1.4);
    root.add(coffee);

    // --- a framed photo standing on the coffee table (sideTable role) ---
    HP().sideTable.forEach((id, i) => {
      const f = makeStandingFrame(P() + id + "_sm.webp", M,
        { width: 0.34, ratio: 1.32, anisotropy: quality.aniso, glass: true });
      f.position.set(1.15 + i * 0.5, G + 0.44 + 0.28, 1.4);
      f.rotation.y = -0.35;
      root.add(f);
    });

    // --- fireplace + mantel with two photos ---
    const fpX = -W / 2 + T + 0.4;
    const surround = new THREE.Mesh(roundedBox(0.5, 2.5, 2.4, 0.05, 1), M.stone);
    surround.position.set(fpX, G + 1.25, -2.0);
    root.add(surround);
    const firebox = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.2, 1.4), M.backing);
    firebox.position.set(fpX + 0.22, G + 0.7, -2.0);
    root.add(firebox);
    const emberGlow = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowSprite("rgb(255,140,60)"), color: 0xff8c3c,
      transparent: true, opacity: 0.65, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    emberGlow.scale.set(1.5, 1.0, 1);
    emberGlow.position.set(fpX + 0.3, G + 0.5, -2.0);
    root.add(emberGlow);
    anim.sprites.push({ sprite: emberGlow, base: 0.65, amp: 0.18, speed: 2.1 });
    const fireLight = addLight(new THREE.PointLight(0xff8a44, 5, 6, 2), { kind: "fire", zone: "interior" });
    fireLight.position.set(fpX + 0.6, G + 0.7, -2.0);
    anim.lights.push({ light: fireLight, base: 5, amp: 1.4, speed: 5.2 });

    const mantel = new THREE.Mesh(roundedBox(0.66, 0.14, 2.7, 0.03, 1), M.woodDark);
    mantel.position.set(fpX + 0.06, G + 1.62, -2.0);
    root.add(mantel);
    HP().mantel.forEach((id, i) => {
      const f = makePhotoFrame(P() + id + "_sm.webp", M, {
        width: 0.42, ratio: 1.3, frame: "frameGold",
        anisotropy: quality.aniso, glass: true
      });
      f.position.set(fpX + 0.28, G + 2.05, -2.7 + i * 1.35);
      f.rotation.y = Math.PI / 2;
      root.add(f);
      liftPhoto(f);   // emissive lift instead of a dedicated light
    });

    // --- "BIRTHDAY BOY · DIPIN" sign above the fireplace ---
    {
      const tex = textTexture(C().house.birthdayBoy, {
        w: 2048, h: 256, font: "500 130px Inter, Arial, sans-serif",
        letter: 26, color: "#fff3de", glow: "#ffb066", glowBlur: 26
      });
      const board = new THREE.Mesh(roundedBox(3.9, 0.68, 0.1, 0.05, 2), M.wallAccent);
      const face = new THREE.Mesh(new THREE.PlaneGeometry(3.62, 0.5),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }));
      face.position.z = 0.056;
      face.renderOrder = 2;
      const sign = new THREE.Group();
      sign.add(board, face);
      // flush against the interior plaster face so the slab reads as
      // mounted, never floating (the plaster sits at -id/2)
      sign.position.set(0, G + 3.15, -id / 2 + 0.055);
      root.add(sign);
      const sl = addLight(new THREE.PointLight(0xffc98a, 2.2, 5, 2), { kind: "sign", zone: "interior" });
      sl.position.set(0, G + 3.7, -id / 2 + 1.4);
    }

    // --- banner strung across the room ---
    const banner = makeBanner(M, window.BDAY_CONFIG.house.banner,
      6, new THREE.Vector3(-iw / 2 + 0.4, G + 3.5, -id / 2 + 0.5),
      new THREE.Vector3(iw / 2 - 0.4, G + 3.5, -id / 2 + 0.5), 0.75);
    root.add(banner);
    anim.flags.push(...banner.userData.flags);

    // --- fairy lights along two walls ---
    [
      [new THREE.Vector3(-iw / 2 + .2, G + 3.9, id / 2 - .3), new THREE.Vector3(iw / 2 - .2, G + 3.9, id / 2 - .3), 0.5],
      [new THREE.Vector3(iw / 2 - .3, G + 3.9, id / 2 - .3), new THREE.Vector3(iw / 2 - .3, G + 3.9, -id / 2 + .3), 0.45]
    ].forEach(([a, b, sag]) => {
      const sl = makeStringLights(M, a, b, sag, 12);
      root.add(sl);
      anim.bulbs.push(...sl.userData.bulbs);
    });

    // --- pendant lights over the cake ---
    [[-1.5, 0.4], [-1.9, -2.6], [2.6, 0.6]].forEach(([x, z], i) => {
      const pl = makePendantLight(M, new THREE.Vector3(x, G + H0 - 0.35, z), 0.8 + i * 0.22, 0.24);
      root.add(pl);
    });
    // one broad room light does the work of three pendants
    const roomLight = addLight(new THREE.PointLight(0xffc98a, 7, 13, 2), { kind: "room", zone: "interior" });
    roomLight.position.set(0.4, G + H0 - 1.0, -0.4);

    // --- lamps + plants ---
    const lamp = makeLamp(M, 1.5);
    lamp.position.set(4.6, G, 2.9);
    root.add(lamp);
    const ll = addLight(new THREE.PointLight(0xffbd7e, 3.4, 5, 2), { kind: "lamp", zone: "interior" });
    ll.position.set(4.6, G + lamp.userData.lightY, 2.9);

    [[-5.9, 4.3], [4.9, -3.4]].forEach(([x, z]) => {
      const pl = makePlant(M, 1.2);
      pl.position.set(x, G, z);
      root.add(pl);
    });

    // --- balloon clusters in the corners ---
    [[-4.4, -3.4, 0], [4.6, 3.6, 2]].forEach(([x, z, seed]) => {
      const cl = makeBalloonCluster(M, 7, 0.62, seed);
      cl.position.set(x, G + 2.0, z);
      root.add(cl);
      cl.children.forEach(b => anim.balloons.push(b));
    });

    /* --- the wishes: little paper notes that float up after the cake --- */
    {
      const texts = C().house.wishes || [];
      const spots = [
        [-2.0, 2.30, -0.2, -0.24], [2.5, 2.50, -0.6, 0.28],
        [-1.4, 2.95, 0.9, -0.14], [1.8, 2.10, 1.0, 0.18],
        [0.1, 3.25, -1.0, 0.04], [-2.7, 1.95, 1.3, -0.34]
      ];
      const cards = [];
      texts.slice(0, spots.length).forEach((txt, i) => {
        const [x, dy, z, ry] = spots[i];
        const tex = textTexture(txt, {
          w: 1024, h: 512, font: "400 90px 'Cormorant Garamond', Georgia, serif",
          letter: 2, color: "#5b3a33", glow: null, bg: "#f7ead3"
        });
        const card = new THREE.Mesh(
          new THREE.PlaneGeometry(1.16, 0.58),
          new THREE.MeshBasicMaterial({
            map: tex, transparent: true, opacity: 0, toneMapped: false,
            side: THREE.DoubleSide, depthWrite: false
          }));
        card.position.set(x, G + dy, z);
        card.rotation.y = ry;
        card.renderOrder = 3;
        card.userData = { baseY: G + dy, seed: i * 1.7, dynamic: true };
        root.add(card);
        cards.push(card);
      });
      anim.wishCards = cards;
    }

    /* --- indoor confetti for the gifts + wishes beat ---
       GPU particles: fall + sway + loop-back is a pure function of
       uTime in the vertex shader (see the rooftop confetti in
       Environment.js for the same pattern) — no per-frame CPU loop
       rewriting a position buffer for this any more. */
    {
      const n = quality.mobile ? 70 : 150;
      const pos = new Float32Array(n * 3);
      const col = new Float32Array(n * 3);
      const seed = new Float32Array(n);
      const vyArr = new Float32Array(n);
      const TOP = G + 4.1, BOTTOM = G + 0.15, SPAN = TOP - BOTTOM;
      const palette = [[1, .84, .55], [.93, .55, .63], [.66, .74, 1], [1, .95, .88], [.82, .58, .88]];
      for (let i = 0; i < n; i++) {
        const x = (Math.random() - 0.5) * 9.4;
        const y = G + 0.4 + Math.random() * 3.6;
        const z = (Math.random() - 0.5) * 7.6;
        pos[i * 3] = x; pos[i * 3 + 1] = y; pos[i * 3 + 2] = z;
        const c = palette[i % palette.length];
        col[i * 3] = c[0]; col[i * 3 + 1] = c[1]; col[i * 3 + 2] = c[2];
        seed[i] = Math.random() * 6.28;
        vyArr[i] = 0.25 + Math.random() * 0.7;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
      geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
      geo.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
      geo.setAttribute("aVy", new THREE.BufferAttribute(vyArr, 1));
      const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true,
        uniforms: {
          uTime: { value: 0 }, uAmt: { value: 0 }, uSize: { value: quality.mobile ? 16 : 22 },
          uTop: { value: TOP }, uBottom: { value: BOTTOM }, uSpan: { value: SPAN }
        },
        vertexShader: `
          attribute float aSeed; attribute float aVy;
          uniform float uTime; uniform float uSize; uniform float uTop; uniform float uBottom; uniform float uSpan;
          varying vec3 vColor;
          void main(){
            vColor = color;
            float rawY = position.y - aVy * uTime * 1.1;
            float y = mod(rawY - uBottom, uSpan) + uBottom;
            float x = position.x + sin(uTime * 1.3 + aSeed) * 0.32;
            float z = position.z + cos(uTime * 1.0 + aSeed) * 0.32;
            vec4 mv = modelViewMatrix * vec4(x, y, z, 1.0);
            gl_PointSize = clamp(uSize / -mv.z, 1.0, 16.0);
            gl_Position = projectionMatrix * mv;
          }`,
        fragmentShader: `
          uniform float uAmt;
          varying vec3 vColor;
          void main(){
            float d = length(gl_PointCoord - 0.5) * 2.0;
            if (d > 1.0) discard;
            float a = uAmt * 0.9;
            gl_FragColor = vec4(vColor, a);
          }`
      });
      const pts = new THREE.Points(geo, mat);
      pts.frustumCulled = false;
      pts.visible = false;
      pts.userData.dynamic = true;
      root.add(pts);
      anim.roomConfetti = { points: pts, mat, geo };
    }
  }

  /* =====================================================
     STAIRCASE — ascending memory gallery
     ===================================================== */
  {
    const wallX = -W / 2 + T + 0.06;
    HP().stairs.forEach((id, i) => {
      const t = i / (HP().stairs.length - 1);
      const y = G + 1.9 + t * 2.6;
      const z = 2.4 - t * 5.2;
      const f = makePhotoFrame(P() + id + "_sm.webp", M, {
        width: 0.5 + (i % 2) * 0.1, ratio: 1.32,
        frame: i % 2 ? "frameWood" : "frameCream",
        anisotropy: quality.aniso, glass: true
      });
      f.position.set(wallX, y, z);
      f.rotation.y = Math.PI / 2;
      root.add(f);
      liftPhoto(f, 0.14);              // gentler lift — the wall was over-lit
    });

    // sconces lighting the flight
    [[G + 2.6, 1.4], [G + 3.8, -2.0]].forEach(([y, z]) => {
      const sc = new THREE.Mesh(new THREE.SphereGeometry(0.11, 12, 10), M.emitWarm);
      sc.position.set(wallX + 0.2, y, z);
      root.add(sc);
    });
    const stairLight = addLight(new THREE.PointLight(0xffc188, 3.1, 9, 2), { kind: "sconce", zone: "interior" });
    stairLight.position.set(wallX + 0.9, G + 3.2, -0.3);
    // the second flight needs its own lantern or the climb goes black
    const upFlight = addLight(new THREE.PointLight(0xffc9a0, 6.5, 12, 2), { kind: "sconce", zone: "interior" });
    upFlight.position.set(STAIR_X + 0.9, F1 + 2.6, 0.4);
    const sconce2 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 12, 10), M.emitWarm);
    sconce2.position.set(wallX + 0.2, F1 + 2.5, -0.6);
    root.add(sconce2);
  }

  /* =====================================================
     UPPER FLOOR — the gallery lounge
     Memory wall + a room you could actually sit in: bookcase,
     reading corner, writing desk, lamps, plants. Nothing floats
     over the stairwell, and no frame ever lands on a window.
     ===================================================== */
  {
    const rug = makeRug(M, 4.2, 3.0);
    rug.position.set(2.0, U + 0.02, 1.2);
    root.add(rug);

    // --- the memory wall (back wall, 6 photos, staggered grid) ---
    const wallZ = -D / 2 + T + 0.07;
    const grid = [
      [-2.7, 2.05, 0.78], [0.0, 2.35, 0.92], [2.7, 2.05, 0.78],
      [-2.7, 0.85, 0.62], [0.0, 0.80, 0.70], [2.7, 0.85, 0.62]
    ];
    HP().memoryWall.forEach((id, i) => {
      const [x, dy, w] = grid[i];
      const f = makePhotoFrame(P() + id + ".webp", M, {
        width: w, ratio: 1.33,
        frame: i === 1 ? "frameGold" : (i % 2 ? "frameWood" : "frameCream"),
        matWidth: 0.06, anisotropy: quality.aniso, glass: true
      });
      f.position.set(x, U + 0.85 + dy, wallZ);
      root.add(f);
    });
    // a proper wall wash so the gallery reads clearly.
    // (Softened: the old 26-intensity, 0.95-angle spot blew out the two
    // centre frames of the memory wall while the corners sat in shadow.)
    {
      const sp = new THREE.SpotLight(0xffe0bd, 17, 12, 1.05, 0.85, 1.5);
      sp.position.set(0, U + 3.6, wallZ + 3.0);
      sp.target.position.set(0, U + 2.0, wallZ);
      root.add(sp, sp.target);
      lights.push(sp);
      sp.userData.kind = "gallery";
      [-2.8, 0, 2.8].forEach(x => {
        const fix = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.08, 0.18, 10), M.brassDark);
        fix.position.set(x, U + 3.62, wallZ + 2.4);
        fix.rotation.x = 0.5;
        root.add(fix);
      });
    }
    // a plaque under the wall, so it reads as a proper exhibition
    {
      const tex = textTexture(C().house.galleryPlaque || "TWENTY YEARS · IN FRAMES", {
        w: 1600, h: 200, font: "400 92px Inter, Arial, sans-serif",
        letter: 22, color: "#ffe7c4", glow: "#ff9d4d", glowBlur: 16
      });
      const plaque = new THREE.Mesh(new THREE.PlaneGeometry(3.2, 0.4),
        new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, toneMapped: false }));
      plaque.position.set(0, U + 0.62, wallZ + 0.02);
      plaque.renderOrder = 2;
      root.add(plaque);
    }

    // --- the easter egg: one small gold frame, set apart from the grid ---
    // Slightly off to the right, in the quiet gap between the rows. It
    // catches a faint warm pulse and rewards a tap with a cinematic
    // overlay (wired up in house/index.js). Fully optional — the wall
    // works perfectly without ever finding it.
    {
      const hero = C().photos && C().photos.hero ? C().photos.hero : "p17";
      const ef = makePhotoFrame(P() + hero + "_sm.webp", M, {
        width: 0.24, ratio: 1.33, frame: "frameGold",
        matWidth: 0.028, anisotropy: quality.aniso, glass: true
      });
      ef.position.set(4.3, U + 2.18, wallZ);
      ef.rotation.z = -0.035;                     // the tiniest lean, like it was hung last
      ef.traverse(o => { o.userData.dynamic = true; });
      ef.userData.dynamic = true;
      root.add(ef);
      liftPhoto(ef, 0.2);
      // a forgiving invisible hit target so a tap anywhere near counts
      const hit = new THREE.Mesh(
        new THREE.SphereGeometry(0.34, 8, 6),
        new THREE.MeshBasicMaterial({ visible: false })
      );
      hit.position.set(4.3, U + 2.22, wallZ + 0.1);
      hit.userData.dynamic = true;
      root.add(hit);
      // the soft pulse that says "notice me" without shouting
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowSprite("rgb(255,214,150)"), color: 0xffd396, transparent: true,
        opacity: 0.34, depthWrite: false, blending: THREE.AdditiveBlending
      }));
      halo.scale.setScalar(0.5);
      halo.position.set(4.3, U + 2.2, wallZ + 0.06);
      root.add(halo);
      anim.easterEgg = { frame: ef, hit, halo };
    }

    // --- side-wall frames, placed clear of every window ---
    const sideFrames = [
      { id: HP().hallway[0], s: -1, z: -4.0, ledge: true },
      { id: HP().hallway[1], s:  1, z:  4.2, ledge: true }
    ];
    sideFrames.forEach(({ id, s, z, ledge }) => {
      const wx = s * (W / 2 - T - 0.07);
      const f = makePhotoFrame(P() + id + "_sm.webp", M, {
        width: 0.72, ratio: 1.32, frame: "frameWood",
        anisotropy: quality.aniso, glass: true
      });
      f.position.set(wx, U + 1.95, z);
      f.rotation.y = -s * Math.PI / 2;
      root.add(f);
      liftPhoto(f);
      if (ledge) {
        const shelfBoard = new THREE.Mesh(roundedBox(0.26, 0.07, 1.1, 0.02, 1), M.woodWarm);
        shelfBoard.position.set(wx - s * 0.1, U + 1.2, z);
        root.add(shelfBoard);
        const pl = makePlant(M, 0.42);
        pl.scale.setScalar(0.5);
        pl.position.set(wx - s * 0.12, U + 1.24, z + 0.34);
        root.add(pl);
        const stack = makeBookStack(M, 3, 1);
        stack.position.set(wx - s * 0.12, U + 1.24, z - 0.3);
        root.add(stack);
      }
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.075, 10, 8), M.emitWarm);
      bulb.position.set(wx - s * 0.16, U + 2.75, z);
      root.add(bulb);
      const wl = addLight(new THREE.PointLight(0xffc98a, 2.2, 4.2, 2), { kind: "sconce", zone: "interior" });
      wl.position.set(wx - s * 0.35, U + 2.5, z);
    });

    // --- the bookcase wall (right side, between the two windows) ---
    const bs = makeBookshelf(M, 2.6, 2.3, 0.44);
    bs.position.set(W / 2 - T - 0.3, U, 0);
    bs.rotation.y = -Math.PI / 2;
    root.add(bs);
    const bsLight = addLight(new THREE.PointLight(0xffc188, 3.2, 6, 2), { kind: "lamp", zone: "interior" });
    bsLight.position.set(W / 2 - T - 1.4, U + 2.2, 0);

    // --- reading corner by the balcony ---
    const chair = makeArmchair(M, 1.05);
    chair.position.set(3.2, U, 3.0);
    chair.rotation.y = Math.PI - 0.55;
    root.add(chair);
    const sideT = makeTable(M, 0.72, 0.72, 0.52, true);
    sideT.position.set(1.7, U, 3.4);
    root.add(sideT);
    const stack2 = makeBookStack(M, 4, 1.1);
    stack2.position.set(1.7, U + 0.52, 3.4);
    root.add(stack2);
    const nookLamp = makeLamp(M, 1.35);
    nookLamp.position.set(4.9, U, 3.4);
    root.add(nookLamp);
    const nookLight = addLight(new THREE.PointLight(0xffbd7e, 3.2, 5.5, 2), { kind: "lamp", zone: "interior" });
    nookLight.position.set(4.9, U + nookLamp.userData.lightY, 3.4);

    // --- a small writing desk in the back-right corner ---
    const desk = makeTable(M, 1.7, 0.8, 0.76);
    desk.position.set(4.4, U, -3.6);
    desk.rotation.y = 0.2;
    root.add(desk);
    const deskChair = makeChair(M, 1);
    deskChair.position.set(4.1, U, -2.7);
    deskChair.rotation.y = Math.PI + 0.2;
    root.add(deskChair);
    const deskLamp = makeLamp(M, 0.72);
    deskLamp.position.set(5.05, U + 0.76, -3.85);
    root.add(deskLamp);
    const dl = addLight(new THREE.PointLight(0xffc188, 2.6, 4.5, 2), { kind: "lamp", zone: "interior" });
    dl.position.set(5.0, U + 1.5, -3.7);
    // a framed photo + books on the desk
    {
      const f = makeStandingFrame(P() + HP().sideTable[0] + "_sm.webp", M,
        { width: 0.3, ratio: 1.32, anisotropy: quality.aniso, glass: true });
      f.position.set(3.9, U + 0.76 + 0.26, -3.7);
      f.rotation.y = 0.4;
      root.add(f);
      liftPhoto(f, 0.3);
      const st = makeBookStack(M, 2, 1);
      st.position.set(4.75, U + 0.76, -3.4);
      root.add(st);
    }

    // --- landing side: a console shelf with plants ---
    const shelf = makeShelf(M, 2.0);
    shelf.position.set(-4.7, U + 1.9, -4.5);
    root.add(shelf);
    [0.5, -0.5].forEach((dx) => {
      const pl = makePlant(M, 0.5);
      pl.scale.setScalar(0.55);
      pl.position.set(-4.7 + dx, U + 1.94, -4.5);
      root.add(pl);
    });
    const cornerPlant = makePlant(M, 1.35);
    cornerPlant.position.set(5.5, U, 4.4);
    root.add(cornerPlant);

    // pendant cluster over the gallery
    [[-0.9, -0.4], [2.2, 0.6]].forEach(([x, z], i) => {
      const pl = makePendantLight(M, new THREE.Vector3(x, U + H1 - 0.4, z), 0.7 + i * 0.2, 0.2);
      root.add(pl);
    });
    const upperLight = addLight(new THREE.PointLight(0xffc98a, 8, 16, 2), { kind: "room", zone: "interior" });
    upperLight.position.set(0.4, U + H1 - 1.1, 0.2);
    const upperFill = addLight(new THREE.PointLight(0xffd0a2, 4.2, 12, 2), { kind: "fill", zone: "interior" });
    upperFill.position.set(1.6, U + 1.8, 2.8);

    // fairy lights following the balcony opening
    const sl = makeStringLights(M,
      new THREE.Vector3(-2.4, U + 3.0, D / 2 - T - 0.2),
      new THREE.Vector3(2.4, U + 3.0, D / 2 - T - 0.2), 0.4, 10);
    root.add(sl);
    anim.bulbs.push(...sl.userData.bulbs);

    // a couple of balloons drifting at the ceiling
    for (let i = 0; i < 5; i++) {
      const b = makeBalloon(M, 0.24 + (i % 3) * 0.05, i + 1, 1.6);
      b.position.set(-1.0 + i * 1.5, U + H1 - 0.9, -0.4 + (i % 2) * 1.4);
      root.add(b);
      anim.balloons.push(b);
    }
  }

  /* =====================================================
     ROOFTOP — the party floor
     A covered stage with a DJ booth and speakers, a glowing
     dance floor under a mirror ball, a cake corner with chairs
     and lanterns, bunting overhead — and fireworks above it all.
     Nothing is placed over the stair opening.
     ===================================================== */
  {
    const terraceLight = addLight(new THREE.PointLight(0xffc98a, 6.5, 18, 2), { kind: "room", zone: "rooftop" });
    terraceLight.position.set(0.6, R + 2.9, 0.4);

    const deckRug = makeRug(M, 4.0, 2.8);
    deckRug.position.set(1.6, R + 0.02, 1.6);
    root.add(deckRug);

    /* ---- the stage: DJ booth + speakers, under the pitched bay ---- */
    const dj = makeDJBooth(M, 2.2);
    dj.position.set(0.4, R, -4.1);
    root.add(dj);
    const djLight = addLight(new THREE.PointLight(0xff8ad0, 9, 9, 2), { kind: "party", zone: "rooftop" });
    djLight.position.set(0.4, R + 1.9, -3.2);
    anim.lights.push({ light: djLight, base: 9, amp: 3.2, speed: 6.2 });
    const djLight2 = addLight(new THREE.PointLight(0x7bd7ff, 6, 8, 2), { kind: "party", zone: "rooftop" });
    djLight2.position.set(-1.4, R + 1.6, -3.4);
    anim.lights.push({ light: djLight2, base: 6, amp: 2.6, speed: 4.4 });

    const speakers = [];
    [[-2.5, -4.3], [3.4, -4.3]].forEach(([x, z]) => {
      const sp = makeSpeaker(M, 1.55);
      sp.position.set(x, R, z);
      sp.rotation.y = x < 0 ? 0.22 : -0.22;
      root.add(sp);
      speakers.push(sp);
    });
    anim.speakers = speakers;

    /* ---- the dance floor (GPU-animated, see Props.js) ---- */
    const floor = makeDanceFloor(M, 5, 4, 0.8);
    floor.position.set(0.8, R, -1.5);
    floor.userData.mesh.userData.dynamic = true;
    root.add(floor);
    anim.danceFloor = { mesh: floor.userData.mesh, mat: floor.userData.mat };

    const ballRig = makeDiscoBall(M, 0.34, 1.5);
    ballRig.position.set(0.8, R + 4.2, -1.5);
    root.add(ballRig);
    ballRig.userData.ball.userData.dynamic = true;
    anim.disco = ballRig.userData;
    const discoLight = addLight(new THREE.PointLight(0xbfd8ff, 6, 11, 2), { kind: "party", zone: "rooftop" });
    discoLight.position.set(0.8, R + 2.4, -1.5);
    anim.lights.push({ light: discoLight, base: 6, amp: 2.0, speed: 2.4 });

    /* ---- the cake corner ---- */
    const rt = makeTable(M, 1.5, 1.5, 0.76, true);
    rt.position.set(3.9, R, 2.2);
    root.add(rt);
    const roofCake = makeCake(M, { candles: 5, scale: 0.8, tiers: 2 });
    roofCake.position.set(3.9, R + 0.76, 2.2);
    root.add(roofCake);
    // this cake is decoration only — the ceremony happens downstairs, so
    // its knife, slice, gap and plate stay hidden for good (the static
    // merge used to resurrect them mid-air)
    ["knife", "slice", "gap", "plate"].forEach(k => {
      const part = roofCake.userData[k];
      if (part) { part.visible = false; part.userData.dynamic = true; }
    });
    // this cake is decoration, so its candles just burn away quietly
    roofCake.userData.candleGroups.forEach(c => { c.scale.y = 1; c.visible = true; });
    if (roofCake.userData.numeral) roofCake.userData.numeral.visible = false;
    anim.flames.push(...roofCake.userData.flames);
    anim.halos.push(...roofCake.userData.halos);
    roofCake.userData.halos.forEach(h => { h.material.opacity = 0.5; });
    const rcl = addLight(new THREE.PointLight(0xffb264, 5, 5, 2), { kind: "cake", zone: "rooftop" });
    rcl.position.set(3.9, R + 1.5, 2.2);
    anim.lights.push({ light: rcl, base: 5, amp: 1.0, speed: 3.1 });

    [[2.6, 3.2, 0.7], [5.2, 3.0, -0.7]].forEach(([x, z, ry]) => {
      const ch = makeChair(M, 0.95);
      ch.position.set(x, R, z);
      ch.rotation.y = ry;
      root.add(ch);
    });
    // lanterns on the parapet
    [-5.2, -2.0, 2.0, 5.2].forEach((x, i) => {
      const lan = new THREE.Mesh(
        new THREE.CylinderGeometry(0.16, 0.2, 0.3, 10),
        new THREE.MeshStandardMaterial({
          color: 0xffd9a0, emissive: 0xffab5e, emissiveIntensity: 1.5,
          roughness: 0.5, transparent: true, opacity: 0.94
        }));
      lan.position.set(x, R + 1.42, D / 2 - 0.15);
      root.add(lan);
      const cap = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.12, 8), M.iron);
      cap.position.set(x, R + 1.62, D / 2 - 0.15);
      root.add(cap);
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowSprite("rgb(255,190,120)"), color: 0xffbe78,
        transparent: true, opacity: 0.45, depthWrite: false, blending: THREE.AdditiveBlending
      }));
      halo.scale.setScalar(0.8);
      halo.position.set(x, R + 1.45, D / 2 - 0.15);
      root.add(halo);
      anim.sprites.push({ sprite: halo, base: 0.45, amp: 0.12, speed: 1.6 + i * 0.3 });
    });

    /* ---- rooftop photo display on easels ---- */
    HP().rooftop.forEach((id, i) => {
      const s = i === 0 ? -1 : 1;
      const f = makePhotoFrame(P() + id + ".webp", M, {
        width: 0.8, ratio: 1.33, frame: "frameGold",
        anisotropy: quality.aniso, glass: true
      });
      const fy = R + 1.35;
      const px = s === -1 ? -4.4 : 5.4;
      const pz = s === -1 ? 4.3 : 4.3;
      f.position.set(px, fy, pz);
      f.rotation.y = -s * 0.55;
      root.add(f);
      const ang = -s * 0.55;
      const ux = Math.cos(ang), uz = -Math.sin(ang);
      [-0.34, 0.34].forEach(dx => {
        const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.035, 1.5, 8), M.woodDark);
        leg.position.set(px + dx * ux, R + 0.75, pz + dx * uz);
        leg.rotation.z = dx * 0.09;
        root.add(leg);
      });
      const ledge = new THREE.Mesh(roundedBox(0.95, 0.07, 0.16, 0.02, 1), M.woodDark);
      ledge.position.set(px, fy - 0.62, pz);
      ledge.rotation.y = ang;
      root.add(ledge);
      const prop = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.03, 1.6, 8), M.woodDark);
      prop.position.set(px - Math.sin(ang) * 0.3, R + 0.8, pz - Math.cos(ang) * 0.3);
      prop.rotation.x = 0.18;
      root.add(prop);
      liftPhoto(f, 0.34);
    });

    /* ---- criss-cross string lights + bunting over the whole terrace ---- */
    const corners = [
      [new THREE.Vector3(-W / 2 + .6, R + 3.4, -D / 2 + 1.0), new THREE.Vector3(W / 2 - .6, R + 2.2, D / 2 - .8)],
      [new THREE.Vector3(W / 2 - .6, R + 3.4, -D / 2 + 1.0), new THREE.Vector3(-W / 2 + .6, R + 2.2, D / 2 - .8)],
      [new THREE.Vector3(-W / 2 + .6, R + 2.6, D / 2 - .8), new THREE.Vector3(W / 2 - .6, R + 2.6, D / 2 - .8)]
    ];
    corners.forEach(([a, b]) => {
      const sl = makeStringLights(M, a, b, 0.9, 16);
      root.add(sl);
      anim.bulbs.push(...sl.userData.bulbs);
    });
    const bunt = makeBunting(M,
      new THREE.Vector3(-W / 2 + 0.8, R + 2.15, -0.6),
      new THREE.Vector3(W / 2 - 0.8, R + 2.15, -0.6), 0.55, 15);
    root.add(bunt);
    anim.flags.push(...bunt.userData.flags);

    /* ---- balloon arch over the stair opening ---- */
    for (let i = 0; i <= 16; i++) {
      const t = i / 16;
      const a = Math.PI * t;
      const b = makeBalloon(M, 0.26 + (i % 3) * 0.05, i, 0.3);
      b.userData.rooftop = true;
      b.position.set(-Math.cos(a) * 5.0, R + Math.sin(a) * 2.4 - 0.4, -D / 2 - 1.8);
      root.add(b);
      anim.balloons.push(b);
    }

    /* ---- floating balloon field, kept off the reveal sightline ---- */
    for (let i = 0; i < 16; i++) {
      const side = i % 2 ? 1 : -1;
      const behind = i % 3 === 0;
      const x = behind ? (Math.random() - 0.5) * 9 : side * (8.6 + Math.random() * 3.4);
      const z = behind ? -(D / 2 + 2.5 + Math.random() * 4) : -5 + Math.random() * 8;
      const b = makeBalloon(M, 0.24 + Math.random() * 0.14, i, 1.3 + Math.random());
      b.position.set(x, R - 1.2 + Math.random() * 4.2, z);
      b.userData.rooftop = true;
      root.add(b);
      anim.balloons.push(b);
    }

    /* ---- planters along the back parapet ---- */
    [-4.6, -1.6, 1.6, 4.6].forEach(x => {
      const pl = makePlant(M, 0.9);
      pl.position.set(x, R, -D / 2 + 1.0);
      pl.scale.setScalar(0.85);
      root.add(pl);
    });

    /* ---- the reveal text ---- */
    const revealGroup = new THREE.Group();
    const hbTex = textTexture(window.BDAY_CONFIG.house.roofTitle, {
      w: 2048, h: 320, font: "400 190px 'Cormorant Garamond', Georgia, serif",
      letter: 26, color: "#fff4e2", glow: "#ffb066", glowBlur: 40
    });
    const hb = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 1.2),
      new THREE.MeshBasicMaterial({ map: hbTex, transparent: true, depthWrite: false, toneMapped: false }));
    hb.position.y = 1.05;
    hb.renderOrder = 3;

    const nmTex = textTexture(window.BDAY_CONFIG.house.roofName, {
      w: 2048, h: 512, font: "600 380px 'Cormorant Garamond', Georgia, serif",
      letter: 22, color: "#ffd89b", glow: "#ff9d4d", glowBlur: 56
    });
    const nm = new THREE.Mesh(new THREE.PlaneGeometry(7.2, 1.8),
      new THREE.MeshBasicMaterial({ map: nmTex, transparent: true, depthWrite: false, toneMapped: false }));
    nm.position.y = -0.25;
    nm.renderOrder = 3;

    const sbTex = textTexture(window.BDAY_CONFIG.house.roofSub, {
      w: 2048, h: 200, font: "300 84px Inter, Arial, sans-serif",
      letter: 20, color: "#f3ddc4", glow: null
    });
    const sb = new THREE.Mesh(new THREE.PlaneGeometry(6.4, 0.62),
      new THREE.MeshBasicMaterial({ map: sbTex, transparent: true, depthWrite: false, toneMapped: false }));
    sb.position.y = -1.35;
    sb.renderOrder = 3;

    revealGroup.add(hb, nm, sb);
    revealGroup.position.set(0, R + 2.0, 1.4);
    revealGroup.scale.setScalar(0.94);
    root.add(revealGroup);
    [hb, nm, sb].forEach(m => { m.material.opacity = 0; m.material.transparent = true; });

    const revealLight = addLight(new THREE.PointLight(0xffb877, 0, 9, 2), { kind: "reveal", zone: "finale" });
    revealLight.position.set(0, R + 2.0, 3.0);

    anim.reveal = { group: revealGroup, planes: [hb, nm, sb], light: revealLight };
  }

  /* =====================================================
     THE ROOM OF WISHES — one floor above the memory wall.
     Every wish that floated up from the cake hangs here as
     a glowing paper lantern. Dark room, warm lights, quiet.
     ===================================================== */
  {
    const wishLight = addLight(new THREE.PointLight(0xffc9a0, 0, 6.5, 2), { kind: "wishroom", zone: "interior", baseWish: 4.4 });
    wishLight.position.set(0, WL + 2.2, -2.0);
    const wishFill = addLight(new THREE.PointLight(0xffb98a, 0, 5.5, 2), { kind: "wishroom", zone: "interior", baseWish: 2.6 });
    wishFill.position.set(-3, WL + 1.8, 2.0);

    // six lanterns on two lines, staggered heights
    const texts = C().house.wishes || [];
    const lanternMat = new THREE.MeshStandardMaterial({
      color: 0xffe3b8, emissive: 0xffb26a, emissiveIntensity: 0.55, roughness: 0.85
    });
    anim.wishLanterns = [];
    texts.slice(0, 6).forEach((txt, i) => {
      // Rows sit deeper in the room (z −2.4 / −3.8) with the middle lanterns
      // staggered sideways: the old front row hung a lantern 0.6 m from the
      // "wishes" camera stop, dead-centre in the lens. Now every lantern
      // keeps at least ~1.5 m clear of the walking line.
      const lx = -3.6 + (i % 3) * 3.6 + (i > 2 ? 1.6 : 0) + (i % 3 === 1 ? 0.6 : 0);
      const lz = i > 2 ? -3.8 : -2.4;
      const ly = WL + 1.95 - (i % 2) * 0.3;
      const g = new THREE.Group();
      const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.09, 0.06, 8), M.brassDark);
      cap.position.y = 0.3;
      const bodyTex = textTexture(txt.toUpperCase(), {
        w: 1024, h: 256, font: "500 92px Inter, Arial, sans-serif",
        letter: 10, color: "#5a3210", glow: null
      });
      const bodyMat = lanternMat.clone();
      bodyMat.emissiveMap = null;
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.26, 0.5, 12, 1, true),
        new THREE.MeshStandardMaterial({
          color: 0xffdfae, emissive: 0xffab5e, emissiveIntensity: 0.5,
          map: bodyTex, roughness: 0.9, side: THREE.DoubleSide
        }));
      const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.16, 0.12, 12, 1, true), bodyMat);
      skirt.position.y = -0.3;
      const tassel = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, 0.22, 6), M.brassDark);
      tassel.position.y = -0.44;
      g.add(cap, body, skirt, tassel);
      // the cord to the ceiling
      const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.7, 4), M.iron);
      cord.position.y = 0.52;
      g.add(cord);
      g.position.set(lx, ly, lz);
      g.traverse(o => { o.userData.dynamic = true; });
      root.add(g);
      anim.wishLanterns.push(g);
      // a soft halo per lantern (joins the glow cloud)
      const halo = new THREE.Sprite(new THREE.SpriteMaterial({
        map: glowSprite("rgb(255,200,130)"), color: 0xffc98a, transparent: true,
        opacity: 0.4, depthWrite: false, blending: THREE.AdditiveBlending
      }));
      halo.scale.setScalar(1.15);
      halo.position.set(lx, ly, lz);
      root.add(halo);
    });
  }

  /* =====================================================
     THE DARKROOM — a shed under the bay roof. Negatives hang
     on a line; as the camera stands in the red light, the
     photographs develop inside them.
     ===================================================== */
  {
    const drX = 2.25, drZ = -3.0, R0 = R;
    // bench with three trays
    const bench = new THREE.Mesh(roundedBox(2.2, 0.08, 0.7, 0.02, 1), M.woodDark);
    bench.position.set(drX, R0 + 0.92, drZ - 0.9);
    root.add(bench);
    [[-0.7, 0x3a2b55], [0, 0x51344a], [0.7, 0x3d2f4e]].forEach(([ox, col]) => {
      const tray = new THREE.Mesh(roundedBox(0.56, 0.1, 0.44, 0.02, 1),
        new THREE.MeshStandardMaterial({ color: col, roughness: 0.35, metalness: 0.1 }));
      tray.position.set(drX + ox, R0 + 1.0, drZ - 0.9);
      root.add(tray);
    });
    // the safelight: red now, warming to white as photos develop
    const safe = addLight(new THREE.PointLight(0xff4a3c, 2.2, 7, 2), { kind: "darkroom", zone: "rooftop" });
    safe.position.set(drX, R0 + 2.0, drZ - 0.4);
    const safeBulb = new THREE.Mesh(new THREE.SphereGeometry(0.09, 10, 8),
      new THREE.MeshStandardMaterial({ color: 0xff6a55, emissive: 0xff3a2a, emissiveIntensity: 1.6 }));
    safeBulb.position.copy(safe.position);
    safeBulb.userData.dynamic = true;
    root.add(safeBulb);
    anim.darkBulb = safeBulb;

    // the line of negatives that develop into photographs
    const negIds = ["p05", "p09", "p13"];
    anim.negatives = [];
    negIds.forEach((id, i) => {
      const nx = drX - 0.7 + i * 0.7;
      const nz = drZ + 0.1;
      const clip = new THREE.Mesh(new THREE.CylinderGeometry(0.015, 0.015, 0.14, 6), M.woodDark);
      clip.position.set(nx, R0 + 1.98, nz);
      root.add(clip);
      // dark negative frame
      const neg = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.62),
        new THREE.MeshStandardMaterial({ color: 0x1d141f, roughness: 0.5,
          emissive: 0x2a0d12, emissiveIntensity: 0.5 }));
      neg.position.set(nx, R0 + 1.62, nz);
      neg.rotation.y = Math.PI;
      // the developed photograph (fades in on top, radially masked shader
      // not needed — a plain opaque plane at 4mm in FRONT of the negative).
      // The old build placed it 4mm BEHIND the opaque negative, so the
      // developing photo was hidden behind a solid dark rectangle.
      const dev = new THREE.Mesh(new THREE.PlaneGeometry(0.46, 0.58),
        new THREE.MeshStandardMaterial({
          map: getPhotoTexture(P() + id + "_sm.webp", quality.aniso),
          roughness: 0.7, transparent: true, opacity: 0, depthWrite: true
        }));
      dev.position.set(nx, R0 + 1.62, nz + 0.004);
      dev.rotation.y = Math.PI;
      dev.renderOrder = 1;   // always above the dark backing plane
      dev.userData.dynamic = true;
      neg.userData.dynamic = true;
      root.add(neg, dev);
      anim.negatives.push({ neg, dev, i });
    });
  }

  return { root, anim, lights };
}
