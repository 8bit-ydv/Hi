/* =============================================================
   MAIN — boot: content injection · start gate · smooth scroll · scenes
   ============================================================= */
(function () {
  const C = window.BDAY_CONFIG;
  const UI = window.UI;
  gsap.registerPlugin(ScrollTrigger);

  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- 1. inject copy from config ---------- */
  document.title = "Happy Birthday, " + C.name;
  document.querySelectorAll("[data-copy]").forEach(el => {
    el.textContent = C.copy[el.dataset.copy] || "";
  });

  const setText = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt || ""; };

  // start gate
  setText("gateKicker", C.gate.kicker);
  setText("gateName", C.gate.name);
  setText("gateSub", C.gate.sub);
  setText("startTxt", C.gate.button);
  setText("gateNote", C.gate.note);

  UI.splitWords(document.getElementById("memoriesLine"), C.copy.memoriesLine);
  UI.splitWords(document.getElementById("yearsLine"), C.copy.yearsLine || "Twenty years, riding one line.");
  UI.splitWords(document.getElementById("roadLine"), C.copy.trainLine || "Every memory, on its way to you.");
  UI.splitWords(document.querySelector('#celebration [data-copy="celebrationLine"]'), C.copy.celebrationLine);
  UI.splitWords(document.querySelector('#finale [data-copy="finaleLine"]'), C.copy.finaleLine);
  setText("finaleMessage", C.copy.finaleMessage);

  // scene iv — house copy
  setText("houseKicker", C.house.kicker);
  setText("houseSub", C.house.sub);
  UI.splitWords(document.getElementById("houseTitle"), C.house.title);

  // scene v — the closing card
  setText("fcKicker", C.finaleCard.kicker);
  setText("fcBig", C.finaleCard.big);
  setText("fcDate", C.finaleCard.date);
  setText("fcLine", C.finaleCard.line);
  {
    const cr = document.getElementById("fcCredit");
    if (cr) {
      cr.textContent = C.finaleCard.credit;
      if (C.audio && C.audio.credit) {
        const m = document.createElement("span");
        m.className = "fc-music";
        m.textContent = C.audio.credit;
        cr.appendChild(m);
      }
    }
  }

  /* ---------- 2. smooth scroll (Lenis ⇄ ScrollTrigger) ---------- */
  if (!reduce && window.Lenis) {
    const lenis = new Lenis({
      duration: 1.15,
      easing: t => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      touchMultiplier: 1.6
    });
    lenis.on("scroll", ScrollTrigger.update);
    gsap.ticker.add(t => lenis.raf(t * 1000));
    gsap.ticker.lagSmoothing(0);
    window.__lenis = lenis;
    lenis.stop();                       // the gate holds the page still
  }

  /* ---------- 3. world canvases ---------- */
  World.init();
  addEventListener("scroll", () => World.setScroll(scrollY), { passive: true });

  /* ---------- 4. preload key images, then start ---------- */
  const critical = [
    ...C.photos.corridor.slice(0, 4),
    ...C.photos.celebration.slice(0, 2)
  ].map(id => C.paths.photos + id + ".webp");

  const bar = document.querySelector("#loader .loader-bar i");
  let done = 0;
  const step = () => {
    done++;
    if (bar) bar.style.width = Math.round((done / critical.length) * 100) + "%";
  };

  Promise.all(critical.map(src => new Promise(res => {
    const im = new Image();
    im.onload = im.onerror = () => { step(); res(); };
    im.src = src;
  }))).then(build);

  // hard timeout so the page never hangs
  setTimeout(build, 5000);

  /* ---------- 5. build the scenes, then show the start gate ---------- */
  let built = false;
  function build() {
    if (built) return;
    built = true;

    Parallax.init();
    if (Scenes.years) Scenes.years();
    Scenes.corridor();
    if (Scenes.road) Scenes.road();
    Scenes.celebration();
    Scenes.house();
    Scenes.finale();
    Scenes.rail();

    ScrollTrigger.refresh();

    document.getElementById("loader").classList.add("done");
    openGate();

    // let the 3D house module mount now that the DOM + scenes are live
    window.__bdayReady = true;
    window.dispatchEvent(new Event("bday:ready"));
    if (window.__lenis) window.__lenis.scrollTo(0, { immediate: true });
    else scrollTo(0, 0);
  }

  /* ---------- 6. the start gate ----------
     One deliberate click: it starts the music (browsers require a
     gesture) and only then unlocks the journey. */
  const gate = document.getElementById("gate");
  const startBtn = document.getElementById("startBtn");

  function openGate() {
    gate.classList.add("on");
    gate.setAttribute("aria-hidden", "false");
    gsap.fromTo("#gate .gate-inner > *",
      { opacity: 0, y: 26, filter: "blur(8px)" },
      { opacity: 1, y: 0, filter: "blur(0px)", duration: 1.2, stagger: 0.16, ease: "power3.out", delay: 0.35 });
  }

  let entered = false;
  let cinema = null;
  function enter(watch) {
    if (entered) return;
    entered = true;

    if (watch) startCinema();
    if (window.BdayAudio) {
      BdayAudio.start();
      const b = document.getElementById("audioBtn");
      if (b) {
        b.classList.add("on");
        const l = b.querySelector(".au-txt");
        if (l) l.textContent = "sound on";
      }
    }

    gsap.to("#gate .gate-inner", {
      opacity: 0, y: -30, filter: "blur(10px)", duration: 0.8, ease: "power2.in"
    });
    gsap.to(gate, {
      opacity: 0, duration: 1.1, delay: 0.25, ease: "power2.inOut",
      onComplete() {
        gate.classList.remove("on");
        gate.style.display = "none";
        gate.setAttribute("aria-hidden", "true");
      }
    });

    document.body.classList.remove("is-loading");
    if (window.__lenis) window.__lenis.start();
    ScrollTrigger.refresh();

    setTimeout(() => {
      const b = document.getElementById("audioBtn");
      if (b) b.classList.add("show");
    }, 1200);
  }

  if (startBtn) startBtn.addEventListener("click", () => enter(false));
  const watchBtn = document.getElementById("watchBtn");
  if (watchBtn) watchBtn.addEventListener("click", () => enter(true));

  /* ---------- cinema mode: the whole journey plays itself ---------- */
  function startCinema() {
    if (cinema) return;
    const hint = document.createElement("p");
    hint.id = "cinemaHint";
    hint.className = "tiny noSel";
    hint.textContent = "playing itself \u00b7 scroll or tap to take over";
    document.body.appendChild(hint);
    requestAnimationFrame(() => hint.classList.add("on"));
    const total = () => document.body.scrollHeight - innerHeight;
    // ~95 px/s of story; the whole night takes about five minutes
    const dur = Math.max(60, total() / 95);
    const proxy = { y: scrollY };
    cinema = gsap.to(proxy, {
      y: total(), duration: dur, ease: "none",
      onUpdate: () => { scrollTo(0, proxy.y); },
      onComplete: stopCinema
    });
    const take = () => stopCinema();
    addEventListener("wheel", take, { passive: true, once: true });
    addEventListener("touchstart", take, { passive: true, once: true });
    addEventListener("keydown", e => { if (e.key === "Escape") take(); }, { once: true });
    cinema._take = take;
  }
  function stopCinema() {
    if (!cinema) return;
    gsap.killTweensOf(cinema);
    cinema.kill && cinema.kill();
    cinema = null;
    const hint = document.getElementById("cinemaHint");
    if (hint) { hint.classList.remove("on"); setTimeout(() => hint.remove(), 600); }
  }
  addEventListener("keydown", e => {
    if (!entered && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); enter(); }
  });

  /* ---------- 7. audio toggle + scroll-linked mix ---------- */
  const audioBtn = document.getElementById("audioBtn");
  if (audioBtn) {
    if (!window.BdayAudio || !BdayAudio.supported) {
      audioBtn.remove();
    } else {
      const label = audioBtn.querySelector(".au-txt");
      audioBtn.addEventListener("click", () => {
        const on = BdayAudio.toggle();
        audioBtn.classList.toggle("on", on);
        label.textContent = on ? "sound on" : "sound off";
      });
      let lastP = -1;
      const total = () => document.body.scrollHeight - innerHeight;
      addEventListener("scroll", () => {
        const p = total() > 0 ? scrollY / total() : 0;
        if (Math.abs(p - lastP) > 0.004) { lastP = p; BdayAudio.setProgress(p); }
      }, { passive: true });
    }
  }

  /* ---------- 8. floor indicator for the house ---------- */
  const floorTag = document.getElementById("floorTag");
  if (floorTag) {
    const span = floorTag.querySelector("span");
    // each label starts at a named camera key, so the badge always
    // matches the room you are actually standing in
    const BY_TAG = [
      ["intro-a", "approach"], ["far", "the house"], ["portico", "entrance"],
      ["enter", "ground floor"], ["cake-approach", "the cake"],
      ["gifts", "gifts & wishes"], ["turn", "staircase"],
      ["stairtop", "upper floor"], ["roofstair", "to the wishes"],
      ["wishfoot", "room of wishes"], ["wishturn", "to the roof"],
      ["emerging", "the darkroom"], ["bayout", "rooftop party"], ["reveal", "the wish"]
    ];
    let floors = null;
    let cur = "";
    const houseSec = document.getElementById("house");
    ScrollTrigger.create({
      trigger: houseSec, start: "top top", end: "bottom bottom",
      onToggle: self => floorTag.classList.toggle("on", self.isActive)
    });
    window.addEventListener("house:progress", e => {
      if (!floors) {
        const app = window.__house && window.__house.app;
        if (!app || !app.tAt) return;
        floors = BY_TAG.map(([tag, name]) => [app.tAt(tag), name])
                       .sort((a, b) => a[0] - b[0]);
      }
      const p = e.detail;
      let name = floors[0][1];
      for (const [at, n] of floors) if (p >= at) name = n;
      if (name !== cur) {
        cur = name;
        gsap.to(span, { opacity: 0, duration: .25, onComplete() {
          span.textContent = name;
          gsap.to(span, { opacity: 1, duration: .45 });
        }});
      }
    });
  }

  /* ---------- 9. housekeeping ---------- */
  if ("scrollRestoration" in history) history.scrollRestoration = "manual";

  let rt;
  addEventListener("resize", () => {
    clearTimeout(rt);
    rt = setTimeout(() => ScrollTrigger.refresh(), 220);
  }, { passive: true });

  // pause heavy work when the tab is hidden
  document.addEventListener("visibilitychange", () => {
    gsap.globalTimeline.timeScale(document.hidden ? 0 : 1);
  });
})();
