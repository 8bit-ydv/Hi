/* =============================================================
   SCENES — scroll-driven story timelines (GSAP + ScrollTrigger)
   i Parallax opening (js/parallax.js) · ii Memory corridor
   iii Celebration · iv The house (3D) · v After the wish
   ============================================================= */
(function (w) {
  const C = w.BDAY_CONFIG, UI = w.UI;
  const mobile = matchMedia("(max-width: 820px)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const SCRUB = reduce ? true : 1.1;

  /* ---------- helpers -------------------------------------- */
  function revealWords(el, trigger, opts = {}) {
    if (!el) return;
    const words = el.querySelectorAll(".word");
    if (!words.length) return;
    gsap.set(words, { yPercent: 115, opacity: 0 });
    gsap.to(words, {
      yPercent: 0, opacity: 1, duration: 1.15, ease: "power3.out",
      stagger: 0.055,
      scrollTrigger: { trigger: trigger || el, start: opts.start || "top 78%", once: true }
    });
  }

  /* =========================================================
     SCENE II — MEMORY CORRIDOR (pinned z-travel through frames)
     ========================================================= */
  /* =========================================================
     SCENE II — MEMORY NEBULA (rebuilt)
     The night sky of scene i carries straight in: the camera now
     drifts THROUGH a nebula of memories — photographs as glowing
     islands among three parallax star layers and slow nebula
     clouds, linked by a stardust thread, swaying like a slow float.
     Scene i stays untouched; this begins after it.
     ========================================================= */
  /* =========================================================
     SCENE II — FALLING STARS (third build, designed for clarity)
     One idea, told once: you fall gently through the night sky.
     Each memory arrives as a shooting star whose streak resolves
     into the photograph; you fall past it; the next one comes.
     Below, the warm light of the party grows until you land in it.
     Scene i stays untouched; this begins after it.
     ========================================================= */
  /* one slide-change beat: a projector click + a soft flash */
  function filmBeat(flashEl) {
    if (w.BdayAudio && BdayAudio.tick) BdayAudio.tick();
    if (!flashEl || reduce) return;
    gsap.killTweensOf(flashEl);
    gsap.fromTo(flashEl, { opacity: 0.5 }, { opacity: 0, duration: 0.55, ease: "power2.out" });
  }

  /* =========================================================
     INTERLUDE — THE YEARS (2006 → 2026)
     A panorama you travel through: one wide world — stars, moon,
     three ridges, a glowing timeline with twenty ticks and the
     years written above them — and scrolling walks you along it.
     Everything moves together at depth speeds, so the sense of
     travelling through time is instant.
     ========================================================= */
  function years() {
    const sec = document.getElementById("years");
    if (!sec) return;
    const rig = document.getElementById("yearsRig");
    const pin = sec.querySelector(".pin");
    const LEN = mobile ? 2400 : 3400;
    /* V15 QA fix — 2026 never reached a readable position: the old travel
       (2vw → -189vw) left the final numeral at ~107vw when the pin ended,
       clipped off the right edge, while its bloom fired with the label
       completely off-screen. The world now travels in three beats:
         steady walk (0→0.68) → 2026 surges in (0.68→0.88) → settle at the
       visual centre (0.88→1.0). The section only ends AFTER 2026 has
       settled around 50vw, on every viewport (all units are vw). */
    const TRAVEL = 248.5;            // vw the world slides leftward (2 → -246.5)

    ScrollTrigger.create({
      trigger: sec, start: "top top", end: () => "+=" + LEN,
      pin: pin, anticipatePin: 1
    });

    /* ---- the sky: our own, fully visible ---- */
    const sky = document.createElement("div"); sky.className = "yr-sky";
    const starsL = document.createElement("div"); starsL.className = "yr-stars";
    let sh = [];
    for (let i = 0; i < (mobile ? 90 : 160); i++)
      sh.push((Math.random() * 100).toFixed(1) + "vw " + (Math.random() * 72).toFixed(1) + "vh 0 " +
              (Math.random() > 0.85 ? 2 : 1) + "px rgba(255,244,226," + (0.25 + Math.random() * 0.6).toFixed(2) + ")");
    starsL.style.boxShadow = sh.join(",");
    const moon = document.createElement("div"); moon.className = "yr-moon";
    const moonGlow = document.createElement("div"); moonGlow.className = "yr-moonglow";
    pin.appendChild(sky); pin.appendChild(starsL); pin.appendChild(moon); pin.appendChild(moonGlow);

    /* ---- the world: one very wide strip, everything inside moves
       together — the ticks and numerals ARE the world ---- */
    const world = document.createElement("div"); world.className = "yr-world";
    rig.appendChild(world);

    // the timeline itself
    const base = document.createElement("div"); base.className = "yr-base";
    world.appendChild(base);
    for (let i = 0; i < 21; i++) {
      const t = document.createElement("div");
      t.className = "yr-tick" + (i % 5 === 0 ? " major" : "");
      t.style.left = (4 + i * 14.6) + "vw";
      world.appendChild(t);
      const yr = 2006 + i;
      if (i % 5 === 0 || i === 20) {
        const lab = document.createElement("div");
        lab.className = "yr-major-num";
        lab.textContent = yr;
        lab.style.left = (4 + i * 14.6) + "vw";
        world.appendChild(lab);
      } else {
        const s = document.createElement("div");
        s.className = "yr-small-num";
        s.textContent = "'" + String(yr).slice(2);
        s.style.left = (4 + i * 14.6) + "vw";
        world.appendChild(s);
      }
    }
    // a warm light travels the timeline as you scroll (the "now")
    const head = document.createElement("div"); head.className = "yr-now";
    world.appendChild(head);

    /* ---- three ridges at depth speeds ---- */
    const RIDGES = [
      { rate: 0.28, col: "linear-gradient(180deg,#241a44 0%,#1b1338 100%)", h: 30, bot: 22,
        clip: "polygon(0 64%,7% 42%,15% 56%,26% 30%,37% 54%,48% 38%,60% 58%,72% 34%,84% 56%,94% 44%,100% 54%,100% 100%,0 100%)" },
      { rate: 0.55, col: "linear-gradient(180deg,#1a1230 0%,#140e26 100%)", h: 24, bot: 16,
        clip: "polygon(0 58%,9% 36%,19% 52%,31% 28%,44% 50%,57% 34%,69% 54%,81% 40%,93% 58%,100% 46%,100% 100%,0 100%)" },
      { rate: 0.85, col: "linear-gradient(180deg,#100a1e 0%,#0c0818 100%)", h: 15, bot: 10,
        clip: "polygon(0 52%,11% 34%,23% 50%,36% 26%,50% 48%,63% 32%,76% 52%,89% 38%,100% 48%,100% 100%,0 100%)" }
    ];
    RIDGES.forEach((r, k) => {
      const el = document.createElement("div");
      el.className = "yr-ridge";
      el.style.left = "-40vw"; el.style.width = "calc(100% + " + (TRAVEL * r.rate + 40) + "vw)";
      el.style.height = r.h + "vh"; el.style.bottom = r.bot + "vh";
      el.style.background = r.col; el.style.clipPath = r.clip;
      world.appendChild(el);
      // the ridges travel in the same three beats as the world, at their
      // own depth speed, so the layers never drift apart
      gsap.timeline({
        scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
      })
        .fromTo(el, { x: "0vw" }, { x: (-131 * r.rate) + "vw", ease: "none", duration: 0.68 }, 0)
        .to(el, { x: (-246 * r.rate) + "vw", ease: "power2.inOut", duration: 0.20 }, 0.68)
        .to(el, { x: (-TRAVEL * r.rate) + "vw", ease: "sine.inOut", duration: 0.12 }, 0.88);
    });

    /* ---- the world itself travels (base + ticks + numerals) ---- */
    gsap.timeline({
      scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
    })
      .fromTo(world, { x: "2vw" }, { x: "-129vw", ease: "none", duration: 0.68 }, 0)
      .to(world, { x: "-246vw", ease: "power2.inOut", duration: 0.20 }, 0.68)
      .to(world, { x: (-TRAVEL + 2) + "vw", ease: "sine.inOut", duration: 0.12 }, 0.88);

    // the travelling "now" light — walks the line and comes to rest on 2026
    gsap.timeline({
      scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
    })
      .fromTo(head, { left: "4vw" }, { left: "229vw", ease: "none", duration: 0.68 }, 0)
      .to(head, { left: (4 + 20 * 14.6) + "vw", ease: "power2.inOut", duration: 0.20 }, 0.68);

    /* ---- 2026 arrives: it has settled at the centre by now, so the
           bloom reads exactly where it should — centred and whole ---- */
    const last = world.querySelectorAll(".yr-major-num");
    const finalNum = last[last.length - 1];
    if (finalNum) {
      gsap.fromTo(finalNum, { color: "rgba(255,236,205,.75)" }, {
        color: "#ffd89b", textShadow: "0 0 44px rgba(255,190,110,.85)", scale: 1.22, transformOrigin: "50% 60%", ease: "none",
        scrollTrigger: { trigger: sec,
          start: () => "top+=" + (LEN * 0.90) + " top",
          end: () => "top+=" + (LEN * 1.03) + " top", scrub: true }
      });
    }
    if (!reduce) {
      const star = document.createElement("div");
      star.className = "yr-star";
      pin.appendChild(star);
      gsap.timeline({
        scrollTrigger: { trigger: sec,
          start: () => "top+=" + (LEN * 0.90) + " top",
          end: () => "top+=" + (LEN * 1.04) + " top", scrub: true }
      })
        .fromTo(star, { opacity: 0, x: "72vw", y: "8vh" },
                       { opacity: 1, x: "26vw", y: "30vh", duration: 1, ease: "none" }, 0)
        .to(star, { opacity: 0, duration: 0.35, ease: "power1.in" }, 0.7);
    }

    // the title
    revealWords(document.getElementById("yearsLine"), sec, { start: "top 70%" });
    gsap.to(sec.querySelector(".scene-title"), {
      opacity: 0, y: -40, ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: "top+=480 top", scrub: true }
    });
  }

  /* =========================================================
     INTERLUDE — THE NIGHT TRAIN
     A long train crosses the dusk: every coach carries one of the
     photographs glowing in its centre window. The camera rides
     alongside — mountains, hills, trees and telegraph poles slide
     past at depth speeds, smoke drifts back, stars come out, and
     a warm station glow receives it at the end. Photos never
     float: they ARE the lit windows of the train.
     ========================================================= */
  function road() {
    const sec = document.getElementById("road");
    if (!sec) return;
    const rig = document.getElementById("roadRig");
    const pin = sec.querySelector(".pin");
    const LEN = mobile ? 2200 : 2900;
    const TRAVEL = 190;                 // vw the world slides

    ScrollTrigger.create({
      trigger: sec, start: "top top", end: () => "+=" + LEN,
      pin: pin, anticipatePin: 1
    });

    /* ---- stars, arriving as the dusk deepens ---- */
    const starsL = document.createElement("div"); starsL.className = "tr-stars";
    let sh = [];
    for (let i = 0; i < (mobile ? 70 : 130); i++)
      sh.push((Math.random() * 100).toFixed(1) + "vw " + (Math.random() * 52).toFixed(1) + "vh 0 1px rgba(255,244,226," + (0.2 + Math.random() * 0.55).toFixed(2) + ")");
    starsL.style.boxShadow = sh.join(",");
    rig.appendChild(starsL);
    gsap.fromTo(starsL, { opacity: 0 }, {
      opacity: 1, ease: "none",
      scrollTrigger: { trigger: sec, start: () => "top+=" + (LEN * 0.3) + " top",
        end: () => "top+=" + (LEN * 0.75) + " top", scrub: true }
    });

    /* ---- generated ridge silhouettes (far + mid) ---- */
    const ridgePoly = (peaks, base) => {
      let pts = "0% " + base + "%";
      for (let i = 0; i <= peaks; i++)
        pts += ", " + (i / peaks * 100).toFixed(1) + "% " + (base - 12 - Math.random() * 26).toFixed(0) + "%";
      pts += ", 100% " + base + "%, 100% 100%, 0% 100%";
      return "polygon(" + pts + ")";
    };
    [{ rate: 0.3, col: "#2c1a3e", h: 34, bot: 34, peaks: 14 },
     { rate: 0.58, col: "#1d112e", h: 26, bot: 24, peaks: 18 }]
    .forEach(r => {
      const el = document.createElement("div");
      el.className = "tr-ridge";
      el.style.left = "-25vw";
      el.style.width = "calc(100% + " + (TRAVEL * r.rate + 25) + "vw)";
      el.style.bottom = r.bot + "vh";
      el.style.height = r.h + "vh";
      el.style.background = r.col;
      el.style.clipPath = ridgePoly(r.peaks, 100);
      rig.appendChild(el);
      gsap.fromTo(el, { x: "0vw" }, {
        x: (-TRAVEL * r.rate) + "vw", ease: "none",
        scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
      });
    });

    /* ---- tree line (mid-near), simple dark spires ---- */
    const treeLine = document.createElement("div");
    treeLine.className = "tr-treeline";
    let trees = "";
    const nT = mobile ? 26 : 44;
    for (let i = 0; i < nT; i++)
      trees += '<span style="left:' + (i / nT * 100 + Math.random() * 1.4) + '%;height:' + (5 + Math.random() * 4).toFixed(1) + 'vh"></span>';
    treeLine.innerHTML = trees;
    treeLine.style.left = "-25vw";
    treeLine.style.width = "calc(100% + " + (TRAVEL * 0.8 + 25) + "vw)";
    rig.appendChild(treeLine);
    gsap.fromTo(treeLine, { x: "0vw" }, {
      x: (-TRAVEL * 0.8) + "vw", ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
    });

    /* ---- the track bed (moves at full speed via its sleepers) ---- */
    const bed = document.createElement("div"); bed.className = "tr-bed";
    const rails = document.createElement("div"); rails.className = "tr-rails";
    rig.appendChild(bed); rig.appendChild(rails);
    gsap.fromTo(bed, { backgroundPositionX: "0vw" }, {
      backgroundPositionX: (-TRAVEL) + "vw", ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
    });

    /* ---- THE TRAIN (camera rides alongside — it stays centred) ----
       The photographs no longer sit as tiny coach windows. They are now
       five large framed memory panels standing beside the rails; the
       coaches glow warm, so the train reads as the journey and the
       panels as the memories found along it. */
    const train = document.createElement("div");
    train.className = "tr-train";
    const ids = ["p08", "p14", "p06", "p12", "p05"];
    let html = "";
    // coaches first (loco at the right — the train runs to the right)
    ids.forEach(() => {
      html += '<div class="tr-coach">' +
        '<span class="tr-win glow"></span>' +
        '<span class="tr-win glow mid"></span>' +
        '<span class="tr-win glow"></span>' +
        '<i class="tr-wheel" style="left:18%"></i><i class="tr-wheel" style="right:18%"></i>' +
        '</div><i class="tr-couple"></i>';
    });
    html += '<div class="tr-loco">' +
      '<span class="tr-body"></span><span class="tr-cab"></span>' +
      '<span class="tr-chimney"></span><span class="tr-catcher"></span>' +
      '<span class="tr-headbeam"></span>' +
      '<i class="tr-wheel big" style="left:12%"></i><i class="tr-wheel big" style="left:38%"></i>' +
      '<i class="tr-wheel big" style="right:12%"></i>' +
      '<span class="tr-smoke s1"></span><span class="tr-smoke s2"></span>' +
      '<span class="tr-smoke s3"></span><span class="tr-smoke s4"></span>' +
      '</div>';
    train.innerHTML = html;
    rig.appendChild(train);
    // a gentle running bob
    if (!reduce) gsap.to(train, { y: "-0.35vh", duration: 1.15, repeat: -1, yoyo: true, ease: "sine.inOut" });

    /* ---- a warm haze in the mid-distance (subtle atmosphere, no fog wall) ---- */
    const haze = document.createElement("div");
    haze.className = "tr-haze";
    rig.appendChild(haze);

    /* ---- THE MEMORY PANELS — a cinematic rhythm, not a scrapbook.
       Each panel is a real framed photograph standing beside the track.
       One at a time:
         a distant panel appears on the right, small and soft,
         approaches the camera (growing, sharpening, straightening up),
         lands at the visual centre with a warm edge light — readable,
         holds a beat,
         then passes the camera and is gone before the next one is born.
       Only one panel owns the frame at any moment; the train and the
       track keep the journey going underneath. */
    const PANEL_IDS = ["p08", "p14", "p06", "p12", "p05"];
    PANEL_IDS.forEach((pid, i) => {
      const el = document.createElement("div");
      el.className = "tr-mem";
      const halo = document.createElement("div");
      halo.className = "tr-mem-halo";
      const fig = document.createElement("figure");
      fig.className = "tr-mem-frame";
      const ph = document.createElement("div");
      ph.className = "tr-mem-photo";
      const img = document.createElement("img");
      img.src = C.paths.photos + pid + "_sm.webp";
      img.alt = ""; img.draggable = false; img.decoding = "async";
      ph.appendChild(img);
      fig.appendChild(ph);
      if (C.captions[pid]) {
        const cap = document.createElement("figcaption");
        cap.className = "tr-mem-cap";
        cap.textContent = C.captions[pid];
        fig.appendChild(cap);
      }
      el.appendChild(halo);
      el.appendChild(fig);
      rig.appendChild(el);

      const t0 = 0.02 + i * 0.15;             // fractions of LEN
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sec,
          start: () => "top+=" + (LEN * t0) + " top",
          end: () => "top+=" + (LEN * (t0 + 0.34)) + " top",
          scrub: SCRUB
        }
      });
      tl.fromTo(el,
        { x: "108vw", scale: 0.86, opacity: 0, filter: "blur(7px)", rotationY: 13, transformPerspective: 900 },
        { x: "46vw", scale: 1, opacity: 1, filter: "blur(0px)", rotationY: 0,
          duration: 0.47, ease: "power1.in" }, 0)
        .to(el, { x: "42vw", duration: 0.23, ease: "sine.inOut" }, 0.47)
        .to(el, { x: "-18vw", scale: 1.15, opacity: 0, filter: "blur(5px)", rotationY: -9,
          duration: 0.30, ease: "power2.in" }, 0.70);
      // the warm edge light rises as the panel settles, fades as it leaves
      tl.fromTo(halo, { opacity: 0 }, { opacity: 1, duration: 0.10, ease: "sine.out" }, 0.42)
        .to(halo, { opacity: 0, duration: 0.12, ease: "sine.in" }, 0.62);
    });

    /* ---- telegraph poles, foreground (fastest) ---- */
    const poles = document.createElement("div");
    poles.className = "tr-poles";
    let ph = "";
    for (let i = 0; i < (mobile ? 7 : 11); i++)
      ph += '<span style="left:' + (i / (mobile ? 7 : 11) * 130 + 4).toFixed(1) + 'vw"></span>';
    poles.innerHTML = ph;
    poles.style.left = "10vw";
    poles.style.width = "calc(100% + " + (TRAVEL * 1.45) + "vw)";
    rig.appendChild(poles);
    gsap.fromTo(poles, { x: "0vw" }, {
      x: (-TRAVEL * 1.45) + "vw", ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: () => "+=" + LEN, scrub: SCRUB }
    });

    /* ---- the receiving station: a warm glow grows ahead, rising as the
           final memory passes, so the panels never compete with it ---- */
    const station = document.createElement("div");
    station.className = "tr-station";
    rig.appendChild(station);
    gsap.fromTo(station, { opacity: 0 }, {
      opacity: 0.95, ease: "none",
      scrollTrigger: { trigger: sec,
        start: () => "top+=" + (LEN * 0.84) + " top",
        end: () => "top+=" + (LEN + 200) + " top", scrub: true }
    });
    // the world sky warms into the celebration
    gsap.timeline({
      scrollTrigger: { trigger: sec, start: "top 85%", end: "top 10%", scrub: SCRUB }
    }).to({ v: 0 }, { v: 0.5, ease: "none",
      onUpdate() { const t = this.targets()[0].v; w.World.setWarm(t); w.World.setStarFade(1 - t * 0.5); } });

    // the title
    revealWords(document.getElementById("roadLine"), sec, { start: "top 70%" });
    gsap.to(sec.querySelector(".scene-title"), {
      opacity: 0, y: -40, ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: "top+=480 top", scrub: true }
    });
  }

  /* =========================================================
     SCENE II — THE MEMORY FILM (restored): a full-screen
     cinematic photo-film with projector dressing.
     ========================================================= */
  function corridor() {
    const sec = document.getElementById("corridor");
    const pin = sec.querySelector(".pin");
    const ids = C.photos.corridor;
    const LEN = mobile ? ids.length * 480 : ids.length * 620;
    const STEP = mobile ? 480 : 620;
    const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"];

    const track = document.createElement("div");
    track.className = "film-track";
    pin.appendChild(track);

    const barTop = document.createElement("div"); barTop.className = "film-bar top";
    const barBot = document.createElement("div"); barBot.className = "film-bar bot";
    const dots = document.createElement("div"); dots.className = "film-dots";
    const dotEls = ids.map(() => { const d = document.createElement("i"); dots.appendChild(d); return d; });
    pin.appendChild(barTop); pin.appendChild(barBot); pin.appendChild(dots);

    const slides = ids.map((id, i) => {
      const s = document.createElement("div");
      s.className = "film-slide";
      s.style.opacity = "0";
      const img = document.createElement("img");
      img.src = C.paths.photos + id + ".webp";
      img.alt = ""; img.draggable = false; img.decoding = "async";
      s.appendChild(img);
      const scrim = document.createElement("span");
      scrim.className = "film-scrim";
      s.appendChild(scrim);
      const cap = document.createElement("div");
      cap.className = "film-cap";
      cap.innerHTML = '<em class="film-num">' + ROMAN[i] + "</em>" +
        (C.captions[id] ? '<span class="film-line">' + C.captions[id] + "</span>" : "");
      s.appendChild(cap);
      track.appendChild(s);
      return { s, img, cap };
    });

    // pin the section for the whole film
    ScrollTrigger.create({
      trigger: sec, start: "top top", end: () => "+=" + LEN,
      pin: pin, anticipatePin: 1
    });

    /* the projector dressing: grain, a light leak, the flash */
    const grain = document.createElement("div"); grain.className = "film-grain";
    const grain2 = document.createElement("div"); grain2.className = "film-grain g2";
    const leak = document.createElement("div"); leak.className = "film-leak";
    const flash = document.createElement("div"); flash.className = "film-flash";
    track.appendChild(grain); track.appendChild(grain2);
    track.appendChild(leak); track.appendChild(flash);

    // the projector flickers to life
    if (!reduce) {
      gsap.timeline({
        scrollTrigger: { trigger: sec, start: "top top", end: "top+=260 top", scrub: true }
      })
        .fromTo(track, { opacity: 0 }, { opacity: 1, duration: 0.15 }, 0)
        .to(track, { opacity: 0.35, duration: 0.08 }, 0.2)
        .to(track, { opacity: 0.95, duration: 0.08 }, 0.34)
        .to(track, { opacity: 0.6, duration: 0.07 }, 0.52)
        .to(track, { opacity: 1, duration: 0.18 }, 0.68);
    }

    /* choreography: crossfade + Ken Burns, one beat each */
    slides.forEach(({ s, img, cap }, i) => {
      const a = i * STEP;
      const inS = () => "top+=" + Math.max(0, a - (i ? 260 : 60)) + " top";
      const inE = () => "top+=" + (a + 200) + " top";
      const outS = () => "top+=" + (a + STEP - 260) + " top";
      const outE = () => "top+=" + (a + STEP + 60) + " top";

      gsap.fromTo(s, { opacity: 0 }, {
        opacity: 1, ease: "power1.inOut", immediateRender: false,
        scrollTrigger: { trigger: sec, start: inS, end: inE, scrub: true,
          onEnter: () => filmBeat(flash), onEnterBack: () => filmBeat(flash) }
      });
      gsap.to(s, {
        opacity: 0, ease: "power1.inOut", immediateRender: false,
        scrollTrigger: { trigger: sec, start: outS, end: outE, scrub: true }
      });
      gsap.fromTo(img,
        { scale: 1.12, xPercent: i % 2 ? 2.4 : -2.4, rotation: i % 2 ? 0.6 : -0.6 },
        { scale: 1.24, xPercent: i % 2 ? -2.4 : 2.4, rotation: 0, ease: "none",
          scrollTrigger: { trigger: sec, start: inS, end: outE, scrub: true } });
      gsap.fromTo(cap, { opacity: 0, y: 26 }, {
        opacity: 1, y: 0, ease: "power2.out", immediateRender: false,
        scrollTrigger: { trigger: sec, start: inS, end: inE, scrub: true }
      });
      gsap.fromTo(dotEls[i], { opacity: 0.22 }, {
        opacity: 1, ease: "none", immediateRender: false,
        scrollTrigger: { trigger: sec, start: inS, end: inE, scrub: true }
      });
    });

    /* cinema bars breathe in, and out at the end */
    gsap.fromTo([barTop, barBot], { height: "0vh" }, {
      height: "7vh", ease: "power2.out",
      scrollTrigger: { trigger: sec, start: "top top", end: "top+=420 top", scrub: true }
    });
    gsap.to([barTop, barBot], {
      height: "0vh", ease: "power2.in",
      scrollTrigger: { trigger: sec,
        start: () => "top+=" + (LEN - 320) + " top",
        end: () => "top+=" + (LEN + 120) + " top", scrub: true }
    });
    gsap.fromTo(dots, { opacity: 0 }, {
      opacity: 1, ease: "none",
      scrollTrigger: { trigger: sec, start: "top+=200 top", end: "top+=500 top", scrub: true }
    });
    gsap.to(dots, {
      opacity: 0, ease: "none",
      scrollTrigger: { trigger: sec,
        start: () => "top+=" + (LEN - 300) + " top",
        end: () => "top+=" + (LEN - 80) + " top", scrub: true }
    });

    /* the last frame lands as a polaroid */
    {
      const pol = document.createElement("div");
      pol.className = "film-polaroid";
      pol.innerHTML =
        '<figure><img src="' + C.paths.photos + (C.photos.hero || "p17") + '_sm.webp" alt="">' +
        '<figcaption>the whole night, in one frame</figcaption></figure>';
      track.appendChild(pol);
      gsap.timeline({
        scrollTrigger: { trigger: sec,
          start: () => "top+=" + (LEN - 520) + " top",
          end: () => "top+=" + (LEN + 160) + " top", scrub: true }
      })
        .fromTo(pol, { opacity: 0, y: "-8vh", rotation: 9, scale: 0.72 },
                       { opacity: 1, y: 0, rotation: -3.5, scale: 1, duration: 1, ease: "power2.out" }, 0)
        .to(pol, { opacity: 0, y: "6vh", duration: 0.35, ease: "power1.in" }, 0.8);
    }

    /* title says its line, then hands the screen to the film */
    revealWords(document.getElementById("memoriesLine"), sec, { start: "top 70%" });
    gsap.to(".corridor-title", {
      opacity: 0, y: -40, filter: "blur(8px)", ease: "none",
      scrollTrigger: { trigger: sec, start: "top top", end: "top+=560 top", scrub: true }
    });
  }

  /* =========================================================
     SCENE III — CELEBRATION (warm shift, lights, balloons)
     ========================================================= */
  function celebration() {
    const sec = document.getElementById("celebration");
    const grid = document.getElementById("cGrid");
    /* the memory wall: each photo arrives veiled, then the frames
       illuminate one by one as the camera holds on the grid */
    C.photos.celebration.forEach(id => {
      const f = UI.photoFrame(id, { small: true, caption: false, veil: true });
      const glow = document.createElement("span");
      glow.className = "frame-glow";
      f.appendChild(glow);
      grid.appendChild(f);
    });
    // the wall starts asleep — veils hold until each frame wakes
    gsap.set(".c-grid .photo .veil", { opacity: 0.82 });

    const bulbs = UI.garland(document.getElementById("garland"), mobile ? 2 : 4);

    // world warms up as we enter
    gsap.timeline({
      scrollTrigger: { trigger: sec, start: "top bottom", end: "top top", scrub: SCRUB }
    })
      .to("#skyWarm", { opacity: 0.55, ease: "none" }, 0)
      .to({ v: 0 }, {
        v: 1, ease: "none",
        onUpdate() { const t = this.targets()[0].v; w.World.setWarm(t); w.World.setStarFade(1 - t * 0.75); }
      }, 0);

    // pin & animate
    const tl = gsap.timeline({
      scrollTrigger: { trigger: sec, start: "top top", end: "+=" + (mobile ? 700 : 1400), scrub: SCRUB, pin: sec.querySelector(".pin") }
    });
    tl.from(".c-grid .photo", {
      yPercent: 55, opacity: 0, filter: "blur(6px)", scale: 0.9, stagger: 0.09, ease: "power2.out",
      // perf: several of these are always mid-transition at once (stagger
      // 0.09 vs a ~0.5s tween == 5-6 overlapping) — filter+box-shadow is
      // one of the most expensive things to repaint, so promote each
      // photo to its own layer only while it's actually animating, then
      // let it go so a wall of 17 photos doesn't sit on 17 GPU layers
      // for the rest of the scroll.
      onStart() { gsap.set(this.targets(), { willChange: "transform, opacity, filter" }); },
      onComplete() { gsap.set(this.targets(), { willChange: "auto" }); }
    }, 0)
      .to("#garland", { y: mobile ? 10 : 24, ease: "none" }, 0)
      .to(".c-grid", { yPercent: -14, ease: "none" }, 0.2)
      // the wall wakes: veils lift one frame at a time, each leaving
      // a little warm light behind it
      .fromTo(".c-grid .photo .veil", { opacity: 0.82 },
        { opacity: 0, stagger: 0.55, duration: 1.4, ease: "power1.inOut" }, 0.55)
      .fromTo(".c-grid .frame-glow", { opacity: 0 },
        { opacity: 0.8, stagger: 0.55, duration: 1.4, ease: "power1.inOut" }, 0.7);

    // bulbs twinkle, plus a wave that runs the length of the garland on entry
    if (!reduce) {
      gsap.fromTo(bulbs, { opacity: 0.1, scale: 0.6 },
        { opacity: 1, scale: 1, transformOrigin: "50% 50%", duration: 0.5, stagger: 0.035,
          ease: "back.out(2)",
          scrollTrigger: { trigger: sec, start: "top 70%", once: true } });
      bulbs.forEach((b, i) => {
        gsap.to(b, {
          opacity: 0.35, duration: 1.1 + (i % 5) * 0.32, repeat: -1, yoyo: true,
          ease: "sine.inOut", delay: 1.2 + i * 0.07
        });
      });
      gsap.to("#garland", { rotation: 0.35, transformOrigin: "50% 0%", duration: 6, yoyo: true, repeat: -1, ease: "sine.inOut" });
    }

    revealWords(document.querySelector('#celebration [data-copy="celebrationLine"]'), sec, { start: "top 62%" });

    // drifting balloons rising through the scene
    const pin = sec.querySelector(".pin");
    (mobile ? [[12, 4], [78, 2]] : [[8, 0], [26, 3], [62, 1], [88, 2]]).forEach(([x, ci], i) => {
      const b = UI.balloon(ci, mobile ? 44 : 66);
      b.style.left = x + "vw";
      b.style.top = "108vh";
      pin.appendChild(b);
      gsap.to(b, {
        y: -(innerHeight * 1.5), ease: "none",
        scrollTrigger: { trigger: sec, start: "top bottom", end: "bottom top", scrub: SCRUB }
      });
      if (!reduce) gsap.to(b, { x: "+=" + (i % 2 ? 26 : -26), duration: 4 + i, yoyo: true, repeat: -1, ease: "sine.inOut" });
    });
  }

  /* =========================================================
     SCENE IV — THE HOUSE (DOM layer; WebGL lives in house.js)
     ========================================================= */
  function house() {
    const sec = document.getElementById("house");
    revealWords(document.getElementById("houseTitle"), sec, { start: "top 72%" });
    gsap.from("#houseKicker, #houseSub", {
      y: 20, opacity: 0, duration: 1.2, stagger: .14, ease: "power2.out",
      scrollTrigger: { trigger: sec, start: "top 70%", once: true }
    });
    // the sky behind cools as we approach the house
    gsap.to("#skyWarm", {
      opacity: .18, ease: "none",
      scrollTrigger: { trigger: sec, start: "top bottom", end: "top top", scrub: SCRUB }
    });
    gsap.from(".house-hint", {
      opacity: 0, duration: 1.4,
      scrollTrigger: { trigger: sec, start: "top 40%", once: true }
    });
    // while the 3D house fills the screen the 2D layers stop drawing entirely
    ScrollTrigger.create({
      trigger: sec, start: "top top", end: "bottom bottom",
      onToggle: self => w.World.setCovered(self.isActive)
    });
    // the parallax world dims as the 3D house takes over — the visual bridge
    gsap.to("#sky, #skyWarm, #starfield, #particles", {
      opacity: 0, ease: "none",
      scrollTrigger: { trigger: sec, start: "top bottom", end: "top 20%", scrub: SCRUB }
    });
    gsap.to("#sky, #skyWarm, #starfield, #particles", {
      opacity: 1, ease: "none",
      scrollTrigger: { trigger: sec, start: "bottom 80%", end: "bottom top", scrub: SCRUB }
    });
  }

  /* =========================================================
     SCENE V — FINALE
     ========================================================= */
  /* =========================================================
     THE STAR SIMULATION — scene v opens with a living sky:
     a tiny glowing house on its island, and the seventeen
     memories leaving it one by one, arcing up into the night
     and settling as the stars of a "20" only they can write.
     One canvas, scrub-driven, drawn only while on screen.
     ========================================================= */
  function starSim() {
    const wrap = document.getElementById("starSim");
    if (!wrap) return;
    const cv = document.getElementById("starSimCanvas");
    const cap = document.getElementById("ssCap");
    const ctx = cv.getContext("2d");
    const W = () => wrap.clientWidth, H = () => wrap.clientHeight;
    let dpr = Math.min(devicePixelRatio || 1, 2);

    const PTS = [
      [0.17, 0.26], [0.83, 0.24],                                  // anchor stars
      [0.285, 0.36], [0.325, 0.31], [0.375, 0.305], [0.402, 0.35], // the "2"
      [0.368, 0.40], [0.322, 0.44], [0.412, 0.465],
      [0.50, 0.30], [0.548, 0.325], [0.566, 0.38], [0.548, 0.435], // the "0"
      [0.50, 0.46], [0.452, 0.435], [0.436, 0.38], [0.452, 0.325]
    ];
    const EDGES = [[2,3],[3,4],[4,5],[5,6],[6,7],[7,8],[0,2],
                   [9,10],[10,11],[11,12],[12,13],[13,14],[14,15],[15,16],[16,9],[1,9]];
    const seeds = PTS.map((_, i) => ({ ph: Math.random() * 6.28, sp: 0.6 + Math.random() * 0.8 }));

    function layout() {
      dpr = Math.min(devicePixelRatio || 1, 2);
      cv.width = W() * dpr; cv.height = H() * dpr;
      cv.style.width = W() + "px"; cv.style.height = H() + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    layout();
    let rt; addEventListener("resize", () => { clearTimeout(rt); rt = setTimeout(layout, 220); }, { passive: true });

    // each memory launches from the house and arcs to its star
    const launchOf = i => 0.05 + i * 0.042;
    const landOf = i => launchOf(i) + 0.115;

    // static sky texture: ambient stars + a moon
    let skyTex = null;
    function buildSky() {
      skyTex = document.createElement("canvas");
      skyTex.width = Math.max(320, W()); skyTex.height = Math.max(240, H());
      const c = skyTex.getContext("2d");
      const sw = skyTex.width, shh = skyTex.height;
      for (let i = 0; i < 150; i++) {
        const a = 0.2 + Math.random() * 0.55;
        c.fillStyle = "rgba(255,244,226," + a.toFixed(2) + ")";
        c.beginPath();
        c.arc(Math.random() * sw, Math.random() * shh * 0.75, Math.random() > 0.9 ? 1.6 : 0.9, 0, 6.284);
        c.fill();
      }
      const mg = c.createRadialGradient(sw * 0.82, shh * 0.16, 6, sw * 0.82, shh * 0.16, 90);
      mg.addColorStop(0, "rgba(255,244,222,.5)");
      mg.addColorStop(0.25, "rgba(255,240,214,.18)");
      mg.addColorStop(1, "rgba(255,240,214,0)");
      c.fillStyle = mg; c.fillRect(sw * 0.82 - 100, shh * 0.16 - 100, 200, 200);
      c.fillStyle = "#f4e9d6";
      c.beginPath(); c.arc(sw * 0.82, shh * 0.16, 13, 0, 6.284); c.fill();
      c.fillStyle = "rgba(228,214,190,.55)";
      [[-4,-3,3],[3,2,2.2],[1,-5,1.6]].forEach(([ox,oy,r]) => {
        c.beginPath(); c.arc(sw * 0.82 + ox, shh * 0.16 + oy, r, 0, 6.284); c.fill();
      });
      // a soft warm horizon
      const hz = c.createLinearGradient(0, shh * 0.78, 0, shh);
      hz.addColorStop(0, "rgba(90,48,70,0)");
      hz.addColorStop(1, "rgba(120,62,80,.4)");
      c.fillStyle = hz; c.fillRect(0, shh * 0.78, sw, shh * 0.22);
    }
    buildSky();
    let rt2; addEventListener("resize", () => { clearTimeout(rt2); rt2 = setTimeout(buildSky, 260); }, { passive: true });

    let prog = 0, live = false, t0 = performance.now();
    function draw(now) {
      if (!live) return;
      const t = (now - t0) / 1000;
      const w = W(), h = H();
      ctx.clearRect(0, 0, w, h);
      if (skyTex) ctx.drawImage(skyTex, 0, 0, w, h);

      // the house: a fuller island home, bottom centre
      const hx = w * 0.5, hy = h * 0.885;
      ctx.save();
      const glow = ctx.createRadialGradient(hx, hy - 44, 6, hx, hy - 44, 210);
      glow.addColorStop(0, "rgba(255,200,130,.30)");
      glow.addColorStop(1, "rgba(255,200,130,0)");
      ctx.fillStyle = glow; ctx.fillRect(hx - 220, hy - 250, 440, 440);
      // island
      ctx.fillStyle = "#0d0a1c";
      ctx.beginPath();
      ctx.moveTo(hx - 150, hy + 30); ctx.quadraticCurveTo(hx, hy - 46, hx + 150, hy + 30);
      ctx.lineTo(hx + 150, hy + 70); ctx.lineTo(hx - 150, hy + 70); ctx.closePath(); ctx.fill();
      // two-storey house
      ctx.fillStyle = "#16112a";
      ctx.fillRect(hx - 46, hy - 66, 92, 62);
      ctx.beginPath();                              // porch roof
      ctx.moveTo(hx - 54, hy - 66); ctx.lineTo(hx, hy - 88); ctx.lineTo(hx + 54, hy - 66); ctx.closePath(); ctx.fill();
      ctx.fillRect(hx + 24, hy - 118, 16, 36);      // chimney
      ctx.fillStyle = "#100c22";
      ctx.fillRect(hx + 40, hy - 6, 26, 32);        // side room
      // roof ridge
      ctx.strokeStyle = "rgba(243,201,139,.35)"; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(hx - 54, hy - 66); ctx.lineTo(hx, hy - 88); ctx.lineTo(hx + 54, hy - 66); ctx.stroke();
      // warm windows (a gentle flicker) — two floors
      const fl = 0.78 + 0.22 * Math.sin(t * 2.7) * Math.sin(t * 1.3);
      ctx.fillStyle = "rgba(255,192,112," + (0.9 * fl).toFixed(3) + ")";
      ctx.fillRect(hx - 34, hy - 58, 11, 13); ctx.fillRect(hx - 16, hy - 58, 11, 13);
      ctx.fillRect(hx + 12, hy - 58, 11, 13);
      ctx.fillRect(hx - 24, hy - 34, 10, 12); ctx.fillRect(hx + 4, hy - 34, 10, 12);
      ctx.fillStyle = "rgba(255,214,150," + (0.7 * fl).toFixed(3) + ")";
      ctx.fillRect(hx + 46, hy + 2, 9, 11);
      // garden lights along the island
      ctx.fillStyle = "rgba(255,220,160,.8)";
      [[-118, 12], [-96, 20], [104, 16], [126, 24]].forEach(([ox, oy]) => {
        ctx.beginPath(); ctx.arc(hx + ox, hy + oy - 40, 1.8, 0, 6.284); ctx.fill();
      });
      ctx.restore();

      // landed stars + the constellation lines between them
      const pos = i => [PTS[i][0] * w, PTS[i][1] * h];
      const landedAll = prog >= landOf(PTS.length - 1);
      const lineP = landedAll ? Math.min(1, (prog - landOf(PTS.length - 1)) / 0.16) : 0;
      if (lineP > 0) {
        ctx.lineWidth = 1;
        const n = Math.floor(EDGES.length * lineP);
        for (let e = 0; e < n; e++) {
          const [a, b] = EDGES[e];
          ctx.strokeStyle = "rgba(255,214,150,.30)";
          ctx.beginPath(); ctx.moveTo(...pos(a)); ctx.lineTo(...pos(b)); ctx.stroke();
        }
      }
      for (let i = 0; i < PTS.length; i++) {
        const landed = prog >= landOf(i);
        if (!landed) continue;
        const [x, y] = pos(i);
        const tw = 0.7 + 0.3 * Math.sin(t * seeds[i].sp * 2 + seeds[i].ph);
        const R = i < 2 ? 1.6 : 2.2 + (i % 3) * 0.5;
        const g = ctx.createRadialGradient(x, y, 0, x, y, R * 5);
        g.addColorStop(0, "rgba(255,244,220," + (0.85 * tw).toFixed(3) + ")");
        g.addColorStop(0.35, "rgba(255,220,160," + (0.35 * tw).toFixed(3) + ")");
        g.addColorStop(1, "rgba(255,220,160,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, R * 5, 0, 6.284); ctx.fill();
        ctx.fillStyle = "rgba(255,248,232," + (0.95 * tw).toFixed(3) + ")";
        ctx.beginPath(); ctx.arc(x, y, R, 0, 6.284); ctx.fill();
      }

      // memories in flight: a bezier arc from the chimney to their star
      for (let i = 0; i < PTS.length; i++) {
        const a0 = launchOf(i), a1 = landOf(i);
        if (prog < a0 || prog >= a1) continue;
        let u = (prog - a0) / (a1 - a0);
        const ease = u * u * (3 - 2 * u);
        const [tx, ty] = pos(i);
        const sx = hx + 30, sy = hy - 116;
        const cx1 = sx + (tx - sx) * 0.25, cy1 = sy - h * 0.28;
        const cx2 = sx + (tx - sx) * 0.75, cy2 = ty + h * 0.14;
        const x = (1 - ease) * (1 - ease) * (1 - ease) * sx + 3 * (1 - ease) * (1 - ease) * ease * cx1 +
                  3 * (1 - ease) * ease * ease * cx2 + ease * ease * ease * tx;
        const y = (1 - ease) * (1 - ease) * (1 - ease) * sy + 3 * (1 - ease) * (1 - ease) * ease * cy1 +
                  3 * (1 - ease) * ease * ease * cy2 + ease * ease * ease * ty;
        // trail
        const g = ctx.createRadialGradient(x, y, 0, x, y, 9);
        g.addColorStop(0, "rgba(255,236,200,.9)");
        g.addColorStop(1, "rgba(255,220,160,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(x, y, 9, 0, 6.284); ctx.fill();
        ctx.fillStyle = "#fff6e2";
        ctx.beginPath(); ctx.arc(x, y, 2.1, 0, 6.284); ctx.fill();
      }
      requestAnimationFrame(draw);
    }

    ScrollTrigger.create({
      trigger: wrap, start: "top top", end: "+=2000",
      pin: wrap, anticipatePin: 1,
      onUpdate: self => {
        prog = self.progress;
        if (cap) {
          if (prog < 0.06) { cap.textContent = "seventeen memories are leaving the house"; cap.style.opacity = Math.min(1, prog / 0.05); }
          else if (prog < landOf(PTS.length - 1)) { cap.textContent = "one by one, into the night"; cap.style.opacity = 1; }
          else if (prog < 0.94) { cap.textContent = "they settle — and write his twenty"; cap.style.opacity = 1; }
          else { cap.style.opacity = Math.max(0, (1 - prog) / 0.06); }
        }
      },
      onToggle: self => {
        live = self.isActive;
        if (live) { t0 = performance.now(); requestAnimationFrame(draw); }
      }
    });
  }

  function finale() {
    const sec = document.getElementById("finale");
    starSim();
    const cluster = document.getElementById("fCluster");
    const layout = mobile
      ? [[4, 1], [54, 11], [10, 30], [56, 42], [6, 62], [52, 74]]
      : [[2, 8], [24, 30], [46, 2], [66, 26], [12, 58], [72, 60]];

    C.photos.finale.forEach((id, i) => {
      const f = UI.photoFrame(id, { small: true, caption: false });
      f.style.left = layout[i][0] + "%";
      f.style.top = layout[i][1] + "%";
      cluster.appendChild(f);

      gsap.from(f, {
        opacity: 0, y: 70, scale: 0.88, filter: "blur(10px)", duration: 1.5, ease: "power3.out",
        scrollTrigger: { trigger: cluster, start: "top 78%", once: true, delay: i * 0.08 }
      });
      gsap.to(f, {
        y: (i % 2 ? -1 : 1) * (mobile ? 40 : 90), ease: "none",
        scrollTrigger: { trigger: cluster, start: "top bottom", end: "bottom top", scrub: SCRUB }
      });
      if (!reduce) {
        gsap.to(f, { y: "+=" + (6 + i * 2), duration: 4 + i * 0.5, repeat: -1, yoyo: true, ease: "sine.inOut" });
        gsap.to(f, { rotation: (i % 2 ? 1 : -1) * 1.1, duration: 7 + i, repeat: -1, yoyo: true, ease: "sine.inOut" });
      }

      /* memories → stars: as the cluster leaves, each photograph
         shrinks away while a small warm light detaches and climbs */
      const dot = document.createElement("span");
      dot.className = "mem-star";
      f.appendChild(dot);
      gsap.timeline({
        scrollTrigger: {
          trigger: "#starLockup", start: "top 95%", end: "top 12%", scrub: SCRUB
        }
      })
        .to(f, { opacity: 0, scale: 0.55, ease: "none" }, 0)
        .fromTo(dot, { opacity: 0, y: 0, scale: 0.4 }, { opacity: 1, scale: 1, ease: "none", duration: 0.3 }, 0)
        .to(dot, { y: -(mobile ? 160 : 260), x: (i % 2 ? 1 : -1) * (26 + i * 9), ease: "none", duration: 1 }, 0.25)
        .to(dot, { opacity: 0, ease: "none", duration: 0.35 }, 0.75);
    });

    /* ---- the star lockup: one clean goodbye ---- */
    const lockup = document.getElementById("starLockup");
    if (lockup) {
      // seventeen quiet specks — one per photograph — twinkle in behind the words
      const specks = lockup.querySelector(".sl-stars");
      const SPN = mobile ? 11 : 17;
      for (let i = 0; i < SPN; i++) {
        const s = document.createElement("i");
        s.style.left = (6 + ((i * 53) % 88)) + "%";
        s.style.top = (8 + ((i * 37) % 84)) + "%";
        s.style.animationDelay = (i * 0.41 % 3.2).toFixed(2) + "s";
        specks.appendChild(s);
      }
      // the sky goes fully to night as the words arrive
      gsap.timeline({
        scrollTrigger: { trigger: lockup, start: "top 90%", end: "top 25%", scrub: SCRUB }
      }).to({ v: 0 }, {
        v: 1, ease: "none",
        onUpdate() { const t = this.targets()[0].v; w.World.setWarm(0.12 * (1 - t)); w.World.setStarFade(0.4 + 0.6 * t); }
      });
      gsap.from(lockup.querySelectorAll(".sl-kicker, .sl-line"), {
        opacity: 0, y: 34, filter: "blur(8px)", duration: 1.6, stagger: 0.22, ease: "power3.out",
        scrollTrigger: { trigger: lockup, start: "top 62%", once: true }
      });
      /* the name arrives word by word, each rising out of its own mask —
         the same language as the opening title, closing the loop */
      const bigEl = lockup.querySelector(".sl-big");
      if (bigEl) {
        // keep the line break: <br> becomes a marker word before splitting
        const words = bigEl.innerHTML
          .replace(/<br\s*\/?>/gi, " <br> ")
          .trim().split(/\s+/)
          .filter(w => w.length);
        bigEl.innerHTML = words
          .map(wd => wd === "<br>"
            ? "<br>"
            : `<span class="w-mask"><span class="w-in word">${wd}</span></span>`)
          .join(" ");
        gsap.fromTo(bigEl.querySelectorAll(".w-in"),
          { yPercent: 118, opacity: 0, rotate: 2 },
          { yPercent: 0, opacity: 1, rotate: 0, duration: 1.5, stagger: 0.24, ease: "power4.out",
            scrollTrigger: { trigger: lockup, start: "top 58%", once: true } });
      }
      /* one quiet meteor crosses the sky as the words land */
      if (!reduce) {
        const meteor = document.createElement("div");
        meteor.className = "sl-meteor";
        lockup.appendChild(meteor);
        ScrollTrigger.create({
          trigger: lockup, start: "top 40%", once: true,
          onEnter: () => {
            gsap.fromTo(meteor,
              { xPercent: 0, yPercent: 0, opacity: 0 },
              { xPercent: 1500, yPercent: 260, opacity: 1, duration: 1.5, ease: "power2.in",
                onUpdate() { gsap.set(meteor, { opacity: 1 - this.progress() * 0.55 }); },
                onComplete: () => meteor.remove() });
          }
        });
      }
      gsap.to(lockup, {
        opacity: 0, y: -60, ease: "none",
        scrollTrigger: { trigger: lockup, start: "bottom 55%", end: "bottom 8%", scrub: SCRUB }
      });
    }

    // cool the world back down for the quiet ending
    gsap.timeline({ scrollTrigger: { trigger: sec, start: "top center", end: "center top", scrub: SCRUB } })
      .to("#skyWarm", { opacity: 0.3, ease: "none" }, 0)
      .to({ v: 1 }, {
        v: 0.25, ease: "none",
        onUpdate() { const t = this.targets()[0].v; w.World.setWarm(t); w.World.setStarFade(1 - t * 0.6); }
      }, 0);

    revealWords(sec.querySelector('[data-copy="finaleLine"]'), sec.querySelector(".center"));
    gsap.from("#finaleMessage", {
      opacity: 0, y: 40, filter: "blur(8px)", duration: 1.6, ease: "power3.out",
      scrollTrigger: { trigger: ".f-msg", start: "top 80%", once: true }
    });
    gsap.from(".f-msg .sign", {
      opacity: 0, y: 20, duration: 1.2, ease: "power2.out",
      scrollTrigger: { trigger: ".f-msg", start: "top 62%", once: true }
    });

    // one soft farewell confetti when the message lands
    ScrollTrigger.create({
      trigger: ".f-msg", start: "top 60%", once: true,
      onEnter: () => w.World.burst(innerWidth / 2, innerHeight * 0.4, 40)
    });

    /* ---- the closing card: the actual last thing you see ---- */
    const card = document.getElementById("fCard");
    if (card) {
      gsap.from(card, {
        opacity: 0, y: 70, scale: 0.94, filter: "blur(10px)",
        duration: 1.6, ease: "power3.out",
        scrollTrigger: { trigger: card, start: "top 82%", once: true }
      });
      gsap.from(card.querySelectorAll(".fc-kicker, .fc-big, .fc-date, .fc-rule, .fc-line, .fc-actions"), {
        opacity: 0, y: 22, duration: 1.1, stagger: 0.13, ease: "power2.out",
        scrollTrigger: { trigger: card, start: "top 76%", once: true }
      });
      gsap.from(".fc-credit", {
        opacity: 0, duration: 1.4,
        scrollTrigger: { trigger: ".fc-credit", start: "top 92%", once: true }
      });
      // a last flurry of confetti + a soft glow pulse on the card
      ScrollTrigger.create({
        trigger: card, start: "top 62%", once: true,
        onEnter: () => {
          let n = 0;
          const iv = setInterval(() => {
            w.World.burst(innerWidth * (0.18 + Math.random() * 0.64),
                          innerHeight * (0.2 + Math.random() * 0.4), 42);
            if (w.BdayAudio && BdayAudio.enabled && BdayAudio.pop) BdayAudio.pop(0.7);
            if (++n > 4) clearInterval(iv);
          }, 260);
        }
      });
      if (!reduce) {
        gsap.to(card, {
          boxShadow: "0 40px 120px -30px rgba(255,170,90,.28)",
          duration: 4.5, repeat: -1, yoyo: true, ease: "sine.inOut"
        });
      }
      const replay = document.getElementById("replayBtn");
      const top = document.getElementById("topBtn");
      const goTop = () => {
        if (w.__lenis) w.__lenis.scrollTo(0, { duration: 2.4 });
        else scrollTo({ top: 0, behavior: "smooth" });
      };
      if (replay) replay.addEventListener("click", goTop);
      if (top) top.addEventListener("click", goTop);
    }
  }

  /* =========================================================
     PROGRESS RAIL
     ========================================================= */
  function rail() {
    const dots = [...document.querySelectorAll("#rail .dot")];
    const secs = ["parallax", "years", "corridor", "road", "celebration", "house", "finale"].map(id => document.getElementById(id));
    document.getElementById("rail").classList.add("on");
    secs.forEach((s, i) => {
      ScrollTrigger.create({
        trigger: s, start: "top 60%", end: "bottom 40%",
        onToggle: self => { if (self.isActive) dots.forEach((d, j) => d.classList.toggle("active", j === i)); }
      });
    });
  }

  w.Scenes = { years, corridor, road, celebration, house, finale, rail };
})(window);
