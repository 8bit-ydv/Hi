# Dipin Birthday World — V15 QA Report

**Date:** 19 August 2026
**Build tested:** `Dipin-Birthday-World-v15.zip` (files: `index.html`, `css/style.css`, `js/*.js`, `js/house/*.js`, `assets/`)
**Method:** the site was served over HTTP and run in a real headless Chromium (WebGL via SwiftShader/ANGLE). The whole journey was driven scroll-by-scroll on three viewports — desktop 1440×900, desktop landscape 1024×576 and mobile 390×844 — including forward → backward → forward scrubbing. Verification used in-page geometry probes (10,002 camera-path samples against a collision model of every slab/ceiling/wall/shed/roof), raycasts of the real merged geometry, ScrollTrigger state inspection, DOM measurements, shader-uniform probes, pixel-statistics on 100+ per-key screenshots, photo aspect-ratio checks, and console/network error capture.

**Result after fixes: 0 console errors, 0 JS exceptions, 0 failed requests on all three viewports.**

---

## 1. Issues found

| # | Severity | Issue | Evidence (V15, measured) |
|---|----------|-------|--------------------------|
| 1 | A — confirmed | **Years scene: 2026 never reaches a readable position.** The world only travelled 2vw → −189vw, leaving the 2026 numeral at **107vw** when the pin released — clipped off the right edge of the viewport — while its "arrival" bloom fired at 0.86–1.02 of the section, i.e. with the label completely off-screen. | DOM rects: at section end, 2026 centre = 1544 px on a 1440 px viewport; only 9 px of the label on-screen. |
| 2 | A — confirmed | **The finale's star simulation pinned over the house intro.** Every ScrollTrigger created before the house module mounted (star-sim pin, all finale once-animations, the floor indicator) held positions measured before the house's 11,200 px pin spacer existed. A global `ScrollTrigger.refresh()` does **not** repair them — during a refresh pass the earlier pins' spacers are still being rebuilt, so triggers after the house re-read the pre-spacer layout and keep the stale numbers. Runtime effect: the star-sim (the "constellation") was pinned `position:fixed` across the full viewport **on top of the house intro and its captions** at house progress 0.08–0.26, and the finale's animations had all fired early, leaving the ending static and empty. | star-sim trigger start = 23,160 while its element sat at 34,360; at scrollY 23,700 (house progress 0.129) `isActive=true`, rect [0, 900], covering the house canvas. |
| 3 | A — confirmed | **Camera passes through solid slabs when climbing.** The three decorative cornice bands were built as solid full-footprint slabs (13.18 × 11.18 m, ~0.22 m thick with bevels) at y 5.02–5.24 (ground line), y 4.77–4.99 (F1 line) and y 8.75–8.97 (FW line) — each crossing the stairwell void. The camera path crosses all three on climbs 1 and 2. | Raycasts: at climb2 the lens had geometry 0.028 m **below** and 0.112 m above it; at climb4, 0.007 m above — the camera inside the slab. |
| 4 | B — visual quality | **Train/rail scene looked childish.** The photographs were 52 × 73 px thumbnails inside coach windows (the train is 1,426 px wide — the photos were less than 4 % of the frame). | DOM measurements of `.tr-win.photo`. |
| 5 | A (small) | **Flight-1 climb grazed the underside of flight 2** (switchback clearance is ~1.52 m vs a 1.62 m standing eye) — the lens dipped up to ~6 cm into flight 2's treads near the top of the first climb; the darkroom door header was also tight for the pushed-back mobile camera, and the desktop darkroom entry hugged the door's right jamb (crossing at x ≈ 2.09 in a 1.1–2.3 opening). | Raycasts at climb2/3; camera-path AABB model (mobile lintel distance 0.046 m). |

Also **verified clean and left untouched** (per the "fix only real problems" rule): the parallax opening (locked), the memory film, the celebration, the cake ceremony (knife tip-first, slice lands on the plate, no z-fighting — V15 fixes present and pure functions of scroll), the gifts (photos rise clear of the boxes), photo aspect ratios (all 17 files measured: declared vs actual ratio deviation 0.0–0.1 %), the house constellation timing itself (appears terrace→reveal, draws reveal→pullback, in the upper sky, clear of the bottom-anchored captions on all viewports), and the rooftop reveal.

## 2. Root cause (per issue)

1. **Years / 2026:** the world-travel distance was authored for the old 2006–2026 layout and never updated: 2026 sits at 296 vw in the world, so reaching the visual centre requires ≈ 246 vw of travel, not 189.
2. **Star-sim over the house:** mount-order + refresh-order defect. `Scenes.finale()` creates its triggers before `mountHouse()` inserts the 11,200 px pin spacer; `ScrollTrigger.refresh()` re-initialises triggers in start order while spacers are still being rebuilt, so post-house triggers keep pre-spacer numbers. (Verified empirically: an individual `trigger.refresh()` repairs it; the next global refresh corrupts it back.)
3. **Cornice bands:** decorative bands built with one solid box spanning the full footprint — no stairwell notches, unlike the floor slabs (which are correctly built as four boards around `VOID_*`).
4. **Train photos:** presentation problem, not data — the photos were placed as window fills, too small to carry the scene.
5. **Climb grazes:** the switchback's real clearance under flight 2 is ~1.52 m — below a standing eye height; the shed door opening (2.05 m) and the desktop darkdoor key left sub-decimetre margins on the spline.

## 3. Files changed

| File | Change |
|------|--------|
| `js/scenes.js` | Years scene: three-beat world travel (steady walk → 2026 surge → settle at ~50 vw) for the world, the three ridge layers and the "now" light; bloom + shooting star retimed to 0.90–1.04 so they play after 2026 is centred. Train scene: coach windows now plain warm glows; added 5 large framed memory panels with a per-panel scroll choreography (approach → focus + warm edge light → pass the camera), a mid-distance haze, and retimed the station glow (0.84+) so panels never compete with it. |
| `css/style.css` | New `.tr-mem` panel styles (frame, mat, warm halo, caption, perspective), `.tr-haze`, `.tr-win.mid`; `.tr-poles` z-index 6 → 7 so poles pass in front of the panels; mobile panel sizing (44 vw); `.yr-base` widened to run past the 2026 tick. |
| `js/house/Architecture.js` | The three cornice bands are now built as four boards around the stairwell void they cross (ground + F1 bands notch `VOID_F1`; the FW band notches `VOID_FW`) — exterior silhouette unchanged, the notches sit well inside the wall line. Darkroom shed door header raised 2.05 → 2.25 m for mobile lens clearance. |
| `js/house/CameraRig.js` | Flight-1 climb keys (`climb1–3`) use a 1.42 m eye (`onF1LOW`) so the lens clears flight 2's treads; `darkdoor` key x 1.45 → 1.25 so the approach crosses the shed doorway at x ≈ 1.7 (the middle of the opening) instead of grazing the right jamb. |
| `js/boot-house.js` | Added a trigger-position repair pass: after every global `ScrollTrigger.refresh()`, every trigger is re-measured individually in document order, so triggers that live after the house's pin spacer read the real layout. This is what keeps the finale (and the floor indicator) correct on load **and after every resize**. |
| `index.html` | Inline `data:` favicon (removes the only 404). |

No other files touched. The opening parallax scene, film, celebration, cake, gifts, mirror, constellation, reveal and all copy are exactly as shipped in the V15 zip.

## 4. Fix implemented (behaviour)

1. **Years:** the world walks at the original pace for 68 % of the section (unchanged feel), then accelerates gently (power2.inOut) as 2026 enters, and settles with a soft sine drift: 2026 is fully visible, centred at **50 vw**, blooming, for the final 10 % of the section, and the section only ends afterwards. The travelling "now" light comes to rest on the 2026 tick. All units are vw, so the centring is identical on every viewport (verified: 49.5–50 vw on 1440 px, 1024 px and 390 px wide screens).
2. **Trigger repair:** the star-sim now pins exactly where the finale begins (34360 px desktop / 27160 px mobile — matching its element position), the finale's reveal animations play when the viewer reaches them, and the floor indicator shows the correct room. Re-runs automatically on every refresh (load, resize), verified by re-measuring after a forced refresh.
3. **Cornice bands:** the camera climbs through open air. The collision model reports **0 penetrations** across 10,002 path samples (desktop + mobile), and raycasts against the real merged geometry show no slab surfaces within 0.22 m of the lens on any climb.
4. **Train:** five large (24 vw desktop / 44 vw mobile, ≈ 346 × 491 px at 1440) framed photographs, each with a thin gold frame, mat, soft warm halo and drop shadow, slight 3D perspective that straightens as the panel approaches, and a serif caption. Exactly one panel owns the frame at a time: it appears distant and soft on the right, approaches and sharpens, holds at the visual centre with its warm edge light, then passes the camera (scale-up, blur, fade) before the next one is born. The train remains fully visible underneath; the panels are real photographs with their true 3:4 aspect ratios — no stretching, no cropping distortion.
5. **Climb clearance:** flight 1 now clears flight 2's treads by ~10 cm at the tightest point; the darkroom entry crosses the door at its centre with ≥ 24 cm of lintel clearance on mobile.

## 5. Desktop verification (1440×900 and 1024×576)

- 2026 centring: label centre 713 px / 1440 (49.5 vw) at pin release; 507 px / 1024 (49.5 vw) — fully visible, blooming, not clipped.
- Train: at f = 0.25/0.40/0.55/0.70/0.85 exactly one panel is at focus (cx ≈ 58 vw, opacity 1) and the previous panel is gone; nothing visible before the first or after the last.
- House: camera at every key tag measured against the collision model — 0 penetrations; constellation uniforms 0 from the intro through the wishes floor; stars appear on the rooftop (appear 0→1 across terrace→reveal), lines draw reveal→pullback, glow peaks at final.
- Star-sim: pins at its real position; at house progress 0.129 the star-sim element sits 10,660 px below the viewport (was: covering it). Sky-region luminance of the house-intro frame = 20.2 vs 94.8 for the actual star-sim frame.
- Captions/hotspots/floor tag: active windows match their camera keys; the floor tag no longer appears during the road/celebration scenes (stale start repaired).
- Console: 0 errors, 0 failed requests (favicon 404 removed).

## 6. Mobile verification (390×844)

- 2026 centring: 193 px / 390 (49.5 vw), fully visible, bloom on-screen.
- Train panels: 44 vw wide, rhythm identical to desktop; panels sit above the train band (panel bottom ≈ 47 vh vs train top ≈ 61 vh) — no covering of the train.
- House: mobile camera push-back sampled against the collision model — 0 penetrations; nearest approach 0.245 m (darkroom door header) and 0.298 m (shed wall) — both clearances, not contacts.
- Star-sim pin matches its element position (27,160 px) after the repair; no overlay of the house at any scroll position.
- Caption/star overlap: constellation projects to y 73–200 px (upper third), captions sit at bottom 15 vh — no overlap.

## 7. Forward → backward → forward verification

Scrubbed: house mid-upper floor → back to the years (f 0.5) → forward again, on both viewports:

- Years: 2026 returns to exactly the position its scroll fraction dictates (204 vw at f 0.5; 50 vw at the end).
- House: camera returns to the same spot on the path (e.g. [-3.9, 4.1, 1.2] mid-climb), constellation uniforms return to 0 (no early constellation after reversing), cake/gift/window states are pure functions of progress (no stale state).
- No duplicated DOM: 1 × years section, 5 × train panels, 8 × film slides, 8 × hotspots after the round-trip.
- No empty scroll regions introduced by state: trigger starts re-verified after reversal.

## 8. Visual checks

- 100+ per-key screenshots on the three viewports: 0 black frames, 0 washed-out frames (all frames within sane luminance range).
- Years end frames: bright centred glow (centre-band max 201–233) = the 2026 bloom, on all viewports.
- Train frames: bright panel region (max 246–248) at every beat, panel absent outside its window.
- House reveal frame: bright reveal region (max 245).
- House intro frame: dark sky (mean 20.2) — no constellation/star-sim overlay.
- Photo aspect ratios: all 17 full + 17 small images measured — deviation from the ratios used by the house systems ≤ 0.1 % (no stretching anywhere; train panels use the same true ratios).

## 9. Performance observations

- No new per-frame work added anywhere: the repair pass runs only on load/resize, the train panels are five DOM elements driven by existing scrubbed tweens (no new rAF loops), the years scene uses the same number of tweens as before, and the cornice bands now cost three extra meshes total (four boards replacing one box, ×3 bands — merged into the static pass like before).
- Photo caching, texture reuse, merged statics, light culling, adaptive resolution and baked shadows are untouched.
- Draw calls/triangle counts unchanged from V15 (measured via `app.stats()` at the memory wall and terrace).

## 10. Remaining known limitations

- **Near-miss, by design:** the switchback staircase is tight by nature — the camera passes ~10 cm under flight 2's treads at the top of the first climb (it no longer touches them) and the darkroom entry has ~24 cm of header clearance on mobile. These read as natural interior navigation, not as clipping.
- The room of wishes' ceiling slab sits low over the upper flight for the same switchback reason; clearance verified ≥ 0.2 m.
- Headless verification used SwiftShader rendering (no GPU vendor specifics); on real GPUs the only difference expected is frame rate, not layout, since every check is geometry/DOM/scroll based.
- Audio (WebAudio score) was started and toggled without errors, but was not listened to by a human in this environment.
- The screenshots were checked by pixel statistics and DOM/geometry probes, not by a human eye.

**Bottom line:** all four reported problems are fixed at their root, the locked opening scene was not touched, and no working system was rewritten.
