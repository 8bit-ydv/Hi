# A Birthday World — from Ekanth, for Dipin

An interactive, scroll-driven birthday experience: a long cinematic parallax
journey that dissolves into a fully explorable **3D birthday house** with three
floors, built entirely in code.

From **Ekanth Yadav** to his brother **Dipin Yadav**,
born **16 October 2006** — turning **twenty**.

---

## The V15 QA pass

*(Full detail in `QA-REPORT-V15.md`.)*

- **2026 gets its moment.** The years journey now travels in three beats — a steady walk, a soft surge as 2026 enters, and a settle — so the final numeral blooms **centred in the viewport** (~50 vw on every screen) before the section moves on. Previously it ended clipped at the right edge, with its bloom firing off-screen.
- **The night train grew up.** The tiny coach-window photos are gone. Five **large framed memory panels** stand along the rails — each approaches from the distance, sharpens, settles at the centre under a warm edge light with its caption, then passes the camera before the next one appears. The coaches glow warm; the train stays the journey, the panels are the memories.
- **The constellation stays on the rooftop.** The finale's star-simulation (and every finale animation) was pinned to scroll positions measured before the house's pin spacer existed — so the constellation used to overlay the house intro and cover its captions. A trigger-position repair pass now re-measures every ScrollTrigger after the house mounts (and after every resize), so the finale plays exactly where it belongs.
- **The camera no longer cuts through the floors.** The decorative cornice bands were solid slabs spanning the whole footprint — including the stairwell. The camera drove straight through them on every climb. Each band now leaves a notch over the stair opening it crosses (invisible from outside), and the first climb's eye height clears the switchback's upper flight with real air to spare.

---

## Run it

There is **no build step** and **no npm install**. Everything is bundled.

**Option A — just open it**
Double-click `index.html`.

**Option B — local server (recommended)**
```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

**Option C — deploy**
Drag this whole folder onto **Netlify Drop**, **Vercel**, **Cloudflare Pages**
or push it to a **GitHub Pages** repo. It is a plain static site — no config
files, no environment variables, nothing to set up.

---

## The journey

| # | Scene | What happens |
|---|-------|--------------|
| I | **Arrival** | Night sky, moon, four layered horizons, drifting balloons. The name reveals word by word. |
| II | **The Journey** | Deep multi-speed parallax; the first photos enter from different depths. |
| III | **The Memory Film** | A full-screen cinematic photo-film: each photograph owns the screen with a slow Ken-Burns breath under cinema bars, crossfading into the next — roman-numeral captions, a progress of dots, and a chord per picture in the live score. Identical on every screen. |
| IV | **Celebration** | The sky warms to sunset, cool dust becomes warm embers, a bulb garland strings overhead. |
| V | **The Reveal** | A spotlit cake assembles tier by tier. **Tap the candles** to blow them out — smoke, confetti, and the message changes. |
| VII | **The House** | *(see below)* |
| VI | **Final Message** | The world cools, a floating photo cluster settles, and the closing message appears. |

### Scene VII — the house

The centrepiece. A real-time 3D house on an island, travelled entirely by
scroll.

**It opens with Ekanth.** Three cinematic title cards — *Ekanth Yadav presents* ·
*for my brother Dipin Yadav* · *who turns Twenty* — play over a wide, high
establishing shot of the lit house. Then a handwritten note appears:

> Bhai — Maine poora ghar saja diya hai.
> Lights lagayi, cake rakha, gubbare bhi.
> Ab bas tu andar aa jaa. Chal, celebrate karte hain.

Only then does the camera begin its descent. The full path:

```
title cards + note → descend → wide arc around the house → garden path →
portico → threshold → ground floor → THE CAKE CEREMONY → staircase →
upper floor → memory wall → second flight → rooftop → HAPPY BIRTHDAY reveal
```

### The cake ceremony

A four-beat set piece on the ground floor, driven entirely by scroll — scrub
backwards and it replays in reverse, perfectly.

| Beat | What happens |
|---|---|
| **The candles are lit.** | A tall "**20**" numeral candle burns on the top tier, flames flickering. |
| **Make the wish, bhai.** | The room dims, the flames stand tall and still, light focuses on the cake. |
| **And blow.** | The flames bend, gutter and go out. Smoke curls up from each wick. |
| **Now cut it.** | A knife descends, sinks into the cake, and a slice lifts out onto a plate. |
| **Happy Birthday, Dipin.** | The final line lands. |

A **BIRTHDAY BOY · DIPIN** sign glows above the fireplace throughout.

**Ground floor** — celebration room: a three-tier cake with a ring of candles and a
**"20" numeral candle** on a
cloth-draped table, gift piles, a sofa and coffee table, a working fireplace
with two framed photos on the mantel, a `HAPPY BIRTHDAY` bunting banner, fairy
lights, pendant lamps and plants.

**Staircase** — an ascending gallery: four framed photographs climbing the wall
beside the flight, lit by sconces.

**Upper floor** — the memory gallery: a six-photograph memory wall in a
staggered grid under a wall wash, two hallway frames on the side walls, a
reading nook, a shelf, and balloons drifting at the ceiling.

**Rooftop terrace** — the finale: a covered bay with a pitched tiled roof,
criss-crossed string lights, a second cake, two photographs on easels, planters
along the parapet, falling confetti, and the **HAPPY BIRTHDAY / DIPIN** reveal
that fades up as you arrive.

Six glowing **hotspots** along the path open cards about Dipin. A floor
indicator on the left tells you where you are. Captions fade in and out with
the camera.

---

## The tenth pass — the night train

The road is gone; in its place, **the night train** — a long train crossing
the dusk with one of the photographs glowing in each coach's centre window
(they are never floating cards; they are the lit windows of the train).
The camera rides alongside: two generated ridge lines and a tree line
slide past at depth speeds, sleepers stream under the rails at full speed,
telegraph poles whip past in the foreground, smoke drifts back from the
chimney, stars come out as the dusk deepens, and a warm station glow
receives the train into the celebration. The score's 96 bpm plucked
"chug" suits it exactly. *(Also found and fixed: both interlude titles had
never been populated — they were silently empty until now.)*

## The ninth pass — the road, for real

- **The Road is now genuinely 3D**: the ground is a CSS plane tipped into
  the distance with true perspective, so the asphalt and its centre dashes
  converge naturally (no more clip-path "rails"). The photographs are
  roadside boards *standing upright on the plane* — born far away, driving
  down the right shoulder, passing the window — with lamp posts streaming
  by on the left shoulder and dark trees on both. A near-field fill keeps
  the ground reaching the bottom of every screen.
- **The finale simulation got a sky**: ambient stars, a cratered moon, a
  warm horizon, and a bigger two-storey house with a chimney, garden
  lights and flickering windows; the constellation spread wider and the
  whole moment tightened (shorter pin, less empty scroll) so the goodbye
  no longer drifts.
- **Perf**: one grain layer on mobile, all road motion scrubbed (no
  per-frame JS), and the earlier light-hysteresis fix stays — no hitching
  anywhere in the walk.

## The eighth pass — the interludes, rebuilt for real

- **The Years, rebuilt**: the section owns its sky now (deep gradient,
  twinkling stars, a moon) and the whole world — the glowing timeline with
  its twenty ticks and year numerals, plus three ridge silhouettes —
  travels together at depth speeds as you scroll, with a "now" light
  walking the line and a shooting star at 2026. Nothing sits still; the
  sense of moving through time is instant.
- **The Road, rebuilt**: a real road — a trapezoid that converges properly
  to a vanishing point at the horizon, white edge lines, a centre-line that
  streams toward you with scroll, three ridge layers sitting exactly on the
  horizon, dark fields, a fast foreground strip — and the photographs as
  roadside milestones that are born at the vanishing point, grow down the
  right edge and sweep past the window, the way milestones do.
- **Scene v opens with a simulation**: a living canvas where a tiny glowing
  house sits on its island and the seventeen memories leave it one by one,
  arcing up into the night and settling as the stars of a "20" — with the
  constellation lines drawing themselves once the last one lands.
- (Also caught and fixed a rewrite slip that had briefly removed the
  memory-film scene entirely.)

## The seventh pass — two interludes and a polaroid

- **The Years** *(new scene, after the opening)* — a ruler of twenty glowing
  ticks and huge year numerals (2006 → 2026) sliding past at three parallax
  depths over silhouetted hills, ending on a shooting star as 2026 arrives.
  The score ticks like a quiet timeline.
- **The Road** *(new scene, between the film and the celebration)* — a dusk
  drive: painted sky, layered hills, a centre-line that flows with your
  scroll, and the road photographs as milestones that grow out of the
  horizon and pass the window. The world sky warms as you crest into the
  party. The score picks up a warm 96 bpm drive.
- **The film ends on a polaroid** — the last frame settles as a physical
  polaroid card, *"the whole night, in one frame."*
- The progress rail now marks all seven scenes.

## The sixth pass — polish + the projector

- **Two ways in, exactly two**: the gate offers *start* (scroll) or
  *sit back & watch* — the duplicated third button is gone.
- **The memory film gained teeth**: the projector flickers to life at the
  top, every slide change lands with a soft flash, a zoom punch and a
  mechanical click in the score, animated film grain and a wandering
  light leak run over the pictures, and the captions are bigger, set
  against a gold rule.
- **Sharper signage**: both facade plates render at 4K textures with
  tighter glow — crisp from the far end of the approach.
- **A dressed exterior**: cornice bands at every floor line, flower boxes
  under the front windows, and 2× wall texture resolution.
- **The door-area hitch is fixed at the root**: the porch lantern no
  longer switches a real light on exactly at the door (each light-count
  change forces the renderer to rebuild its shaders — that was the lag);
  the lantern glows via its bulb and halo, and the light culler now uses
  hysteresis so light sets change rarely and deliberately.

## The fifth pass — two new rooms, a cinema, and a real score

- **The room of wishes** — a whole new floor above the memory wall. Every
  wish that floated up from the cake hangs here as a glowing paper
  lantern, six of them swaying on their cords in a dark, warm room.
- **The darkroom** — at the top of the third flight, a shed under the bay
  roof lit by a red safelight. Negatives hang on a line; as you stand
  there, the photographs develop inside them, and the red light warms to
  white. The staircase now runs ground → upper → wishes → rooftop (three
  flights, all enclosed), and the whole journey grew ~20% longer.
- **Cinema mode** — the start gate now offers two ways in: *start* (you
  scroll) or *sit back & watch* (the whole night plays itself, about five
  minutes; any scroll or tap hands control back to you).
- **A real score** — every scene is now a different piece: its own tempo,
  time signature, key and instruments. The house is a waltz (3/4), the
  wishes room a dreamy one a step up, the darkroom drops low and dark,
  the rooftop reveal jumps an octave with bells, the make-a-wish moment
  is a hush with a slow heartbeat, and the finale of the memory film
  still changes chord with every photograph.
- **Photo-confetti** — the rooftop confetti falls as tiny fragments of a
  photograph.

## The final polish pass

Everything below is additive — the house, the path, the ceremony and every
existing animation are exactly as they were.

- **The house wakes up.** After the establishing shot, the windows settle to
  embers with a single light still on ("it's been on all evening"), then walk
  back up to full — one by one, in narrative order — as the camera arcs in.
  The porch lantern turns on a beat before the door, the garden path lanterns
  come on one after another, and the balcony string lights follow you to the
  threshold. Scrub backwards and the whole sequence plays in reverse.
- **The door opens.** The front door swings wide as the camera crosses the
  steps, warm interior light spilling out with it.
- **The staircase warms up.** The stair sconces sit low while you are on the
  ground floor and rise to full as you start each climb.
- **The memory wall gets its moment.** As the camera settles on the gallery,
  the wall wash lifts while the room softly dims — cinematic attention, then
  back to normal.
- **The rooftop reveal is staged.** The canopy arrives restrained; the strands
  light one after another across the terrace, the terrace and roof-cake lights
  finish coming on with the message.
- **Chimney smoke.** A barely-there wisp drifts from the chimney cap.
- **One hidden memory.** A small gold frame hangs apart from the memory wall,
  breathing faintly. Tap it and it opens the hero photograph in a cinematic
  overlay — *"You found one more memory."* Entirely optional; the journey
  never depends on it.

### The add-on pass — the story deepens (third pass)

Scene i (the parallax opening) was treated as locked and was not touched.
New work begins after it:

- **The corridor breathes.** Each memory now arrives as a soft glow before
  the frame resolves and the photograph fades into focus — and a thin
  golden thread links one memory to the next through the Z-space, lighting
  segment by segment as you walk (desktop).
- **The celebration wall wakes.** The photographs arrive veiled; the frames
  illuminate one by one, each leaving a little warm light behind it.
- **🎁 The gifts contain photographs.** As the camera reaches the gifts by
  the cake, three boxes swing open one after another — warm light from
  inside, and a real framed photograph rises out of each and floats there.
  (Photos are configurable: `house.magic.gifts`.)
- **🪞 The magic mirror.** A gilt mirror hangs on the upper floor between
  the hallway frames. It behaves like a mirror at night — dark glass, a
  slow sheen — and as you arrive, the glass shimmers and a memory surfaces
  *through* it (a radially masked photo, not a pasted rectangle), holds
  while you pass, and fades as you turn to the stairs.
  (`house.magic.mirror` picks the photo.)
- **🌌 The photo constellation.** Every one of the seventeen photographs
  becomes a point in the night sky above the rooftop. The points appear
  one by one as you cross the terrace, thin lines draw the constellation
  through the reveal, the lines brighten as you pull back — and on the
  way out the whole formation drifts gently outward: the memories
  becoming stars. Hover a point (desktop) and its photograph surfaces
  beside it, softly.
- **Memories become stars.** In the finale, the floating cluster
  dissolves — each photograph shrinking away as a small warm light
  detaches and climbs into a now fully starry sky — before one clean
  goodbye: *Happy Birthday, Dipin.*

Every new photograph rides the same shared texture cache as the house
frames (one texture per file, forever), every sequence is a pure function
of scroll — scrub backwards and it replays in reverse — and nothing new
adds a real light to the scene.

### Feedback pass (fourth)

- **The signage moved up.** The DIPIN nameplate (which sat behind the
  balcony balustrade) and the 16 OCTOBER 2006 plaque (lost in the portico
  shadow, low and out of frame) now hang together on the facade band above
  the balcony bay — legible across the whole approach arc. Text materials
  are fog-proof.
- **The cake ceremony cut reads properly.** A real chef's knife (tapered
  tip-down blade, brass bolster, riveted handle) plunges tip-first; the
  wedge now opens toward the ceremony camera so the cut is visible from
  outside; the gap is wider than the slice (no z-fighting, no jitter) and
  the slice exits along the wedge and lands ON the plate.
- **The BIRTHDAY BOY sign** is narrower, so its ends no longer tuck into
  the window curtains.
- **The gift photographs** rise well clear of their boxes (0.4 m of air,
  bigger prints) instead of sitting buried in the pile.
- **The landing turn is fixed.** The camera now walks around flight two
  (behind its foot, then right into the room) instead of clipping straight
  through the staircase, and the stairwell newels are tucked closer to the
  flight.
- **The stair photos calmed down.** Lower sconce bases, a capped wake and a
  gentler emissive lift — the wall is warm now, not floodlit.
- **The rooftop candles sit ON the cake.** The two-tier cake's candle ring
  used to be buried inside the second tier; it now stands on the top
  surface.
- **The constellation is now "20", written in stars.** Instead of floating
  dots over the terrace, seventeen stars far up in the night sky draw the
  number in stroke order — the "2", then the "0" — with faint joining
  lines, subtle sizes, and hover previews for each photograph.

### Glitch fixes (second pass)

- **The front door** is hung on a true hinge — closed it fills the doorway
  (it used to sit half-buried in the wall); open it swings wide of the
  portico column.
- **The BIRTHDAY BOY sign** sits flush against the plaster instead of
  floating 9 cm off the wall.
- **The rooftop cake** no longer has a knife and slice hovering over it —
  the static-merge pass used to resurrect meshes that were built hidden;
  invisible meshes are now exempt from merging (and the speakers' blinking
  LEDs, which the merge had frozen on, blink again).
- **The terrace edges** are sealed — the upper storey now reaches the
  underside of the roof slab; there used to be a 19 cm see-through slit
  around the whole parapet, worst at the corners.
- **The staircase** reads as built joinery: a soffit beneath each flight and
  a skirt on the wall side close the see-through gaps that made flight two
  look like it was floating over the stairwell. Both were placed against the
  actual camera path (verified: 2,000 samples, zero intersections, desktop
  and mobile).

---

## Change the content

Everything editable lives in **`js/config.js`**. Nothing else needs touching.

```js
name              // "Dipin"
from              // "Ekanth Yadav"   — who is wishing
to                // "Dipin Yadav"    — who is being wished
age               // 20               — drives the numeral candle
dob               // "16 October 2006"
copy.*            // every line of text in scenes I-VI

photos.*          // which photo id goes into which parallax scene
captions.*        // optional one-line mood captions

house.nameplate   // text on the sign above the porch      → "DIPIN"
house.datePlaque  // the plaque beside the door            → "16 · 10 · 2006"
house.banner      // the bunting inside                    → "HAPPY BIRTHDAY"
house.roofTitle   // the rooftop reveal, line 1
house.roofName    // the rooftop reveal, line 2
house.roofSub     // the rooftop reveal, line 3
house.photos.*    // photo placement per area of the house
house.intro.cards // the three opening title cards
house.intro.note  // the handwritten note, one line per array entry
house.cake.beats  // the four ceremony captions
house.birthdayBoy // the sign above the fireplace
house.captions[]  // lines that fade in as the camera moves
house.hotspots[]  // { at:[x,y,z], show:[from,to], title, text }
```

Photo ids are `p01`–`p17`, mapped in filename order from the source images.
Each has a full-size `pNN.webp` (~1100px) and a smaller `pNN_sm.webp` (~560px).

**To swap a photo:** drop your new image into `assets/photos/`, save it as
`pNN.webp` and `pNN_sm.webp`, and it appears wherever that id is referenced.

---

## The stunning pass (fifth)

- **Scene ii — REBUILT as The Memory Film** (corridor, nebula and falling
  stars all gone). One bulletproof idea: each photograph owns the whole
  screen — `object-fit: cover`, cinema bars, a slow Ken-Burns zoom, a
  roman numeral and its caption, crossfading to the next picture as you
  scroll. No 3D transforms, no viewport-unit choreography — nothing left
  to break on any phone or laptop. One chord per photograph in the score.
- *(superseded)* the nebula pass — floating islands among star layers.
  Four parallax starfields and three drifting nebula clouds; the eight
  photographs hang as glowing islands at different depths with their
  captions; a stardust thread links them; the whole rig sways like a slow
  float; the hero photograph sweeps centred past the lens with a sparkle
  burst; and a warm destination glow swells at the nebula's heart.
- *(previous pass, superseded)* the corridor was a museum of light — shafts
  cross the space, sixteen dust motes drift at true depths (they parallax
  with the frames), the light trail still threads the memories — and
  mid-corridor the hero photograph sweeps centred and close past the lens,
  growing until it fills the frame. At the far end, a warm destination
  glow swells as you walk: you leave the memories through light.
- **Scene v — the goodbye lands harder.** The name now rises word by word
  out of masked lines (the opening title's language, closing the loop),
  one quiet meteor crosses as the words land, and the closing card wears
  a tiny "20" star-monogram — the rooftop constellation, remembered.
- **The date plaque is legible**: a bolder, brighter, wider-tracked
  engraving on a larger plate.
- **The cake slice no longer jitters**: the slice is 7 % slimmer than the
  notch it rises from (the two solids can never touch), and the notch
  itself now sits proud of the tier — no coincident faces anywhere.
- **The music is bundled and longer**: "Wholesome" (Kevin MacLeod,
  CC BY) — six minutes, downloaded and kept locally at
  `assets/audio/theme.mp3`, no links, loops seamlessly.

## Per-scene music moods

**No audio file ships with the site anymore.** The score is composed live
in the browser with WebAudio — a detuned pad, a music-box celesta, high
bells at the sky, and a whisper of night air — following the journey scene
by scene and movement by movement:

- **one chord per photograph** in the memory film — the harmony changes
  exactly when the picture does
- **the melody climbs the stairs with the camera** (ascending runs over
  both flights)
- the **make-a-wish** moment hushes everything but the lowest pad
- the **rooftop reveal** is the peak: brighter filter, octave doubling,
  sparkle bells
- the rest of the arc: night (veiled) → film (tender) → warm (celebration)
  → approach → interior → wish → cut → rooftop → finale → outro

| mood | where | sound |
|---|---|---|
| night | scene i | veiled pad + night air |
| fall | scene ii | chord per photo, music-box motif |
| warm | scene iii | open and bright, light arpeggio |
| approach | the house fills the frame | full pad |
| interior | inside the house | intimate |
| wish | make-a-wish | almost silence |
| cut | after the candles | coming back |
| rooftop | the climb | lifting, bells begin |
| finale | the reveal | the peak |
| outro | the goodbye | settled |

## Music

There is **no audio file** — see *Per-scene music moods* above. The whole
score (pad, celesta, bells, air) is synthesised on the fly; playback starts
only from the start gate (a real user gesture), and everything is off until
then. To use a real song instead, drop your file into `assets/` and play it
from `js/audio.js` — `start()` is the single entry point.
