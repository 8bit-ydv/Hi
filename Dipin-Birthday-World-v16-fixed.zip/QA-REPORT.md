# Dipin Birthday World — V14 Deep Runtime QA Report

**Date:** 19 August 2026
**Build tested:** `Dipin-Birthday-World-v14.zip` (source of truth: `index.html`, `js/`, `js/house/`, `css/`, `assets/`)
**Method:** the site was served and run in a real headless Chromium (WebGL via SwiftShader), navigated scroll-by-scroll through the entire journey on a desktop (1440×900 / 1024×576) and a mobile (390×844) viewport, scrubbed forward → backward → forward, with in-page geometry probes, raycast occlusion tests, state-property checks, per-key screenshots, pixel-level frame analysis and console/network error capture.

**Result: 0 console errors, 0 failed requests, 0 JS exceptions on either viewport after the fixes.**

### Verification summary (final build)
- Camera spline vs wall AABBs: **0 intersections** (900 samples desktop, mobile sweep included)
- 40 camera keys: floor bands, stair-tread riding, object clearances (cake/gifts/lanterns/negatives) — **all pass**
- Cake ceremony, gifts, mirror, wish cards, darkroom develop, rooftop reveal, window wake — **all pass**
- Forward → backward → forward scrubbing (scene-level and whole-page): **deterministic, no NaN, no stale state, 0 errors**
- Signage raycast from all 9 approach keys: **unobstructed**
- 72 per-key screenshots: **0 black frames, 0 washed-out frames**; region checks confirm lit cake centre (max 255), visible reveal text, developing darkroom photos (max 223), bright memory wall and wish lanterns on both viewports
- Cinema mode: plays itself, hands back on wheel/tap, no errors
- Performance: ~145 draw calls / ~310 k triangles at the memory wall and terrace (desktop); ~100 / ~275 k on mobile

---

## 1. Root-cause fixes (code)

### 1.1 Duplicate camera tag `wishes` — the biggest functional bug
`js/house/CameraRig.js` contained **two camera keys tagged `wishes`**: the ground-floor "gifts & wishes" stop and the upper-floor "room of wishes" stop. The tag→scroll lookup (`TAG_AT`) is built by iterating the keys, so the upper-floor key silently overwrote the ground-floor one. Consequences (all verified at runtime):

- `GIFT_C = tAt("wishes")` resolved **after** `GIFT_END = tAt("stairfoot")`, so the `wishOut` smoothstep was permanently saturated → **the floating wish cards and the indoor confetti never appeared at all**.
- The caption `{from:"gifts", to:"wishes"}` stretched across ~30 % of the entire house scroll instead of the gifts beat, and `{from:"wishes", to:"turn"}` became an inverted window (t0 > t1) that could never fire.
- The three gift boxes in `Magic.js` opened on wrong windows (the 3rd box opened around the upper-floor gallery).

**Fix:** the upper-floor key is now uniquely tagged `wishroom` (and added to the mobile camera push-back regex so mobile framing is unchanged).

### 1.2 Camera clipping the darkroom door jamb
The Catmull-Rom spline through the darkroom shed door overshot its control points and clipped the door's right jamb by ~0.1 m on desktop ("aar-paar"), and on mobile the push-back transform moved the `bayout` key back *inside* the shed — through the wall.

**Fix:** `darkdoor`/`darkroom`/`bayout` keys re-anchored to the door centre line, the shed door widened 1.05 m → 1.2 m in `Architecture.js`, and `bayout` removed from the mobile roomy push-back list (it already stands clear of the shed). Verified by sampling the spline at 400 sub-steps per segment on both viewports: **0 wall intersections**.

### 1.3 Darkroom "developing" photos were invisible
In `Interiors.js` the developed photograph plane was placed **4 mm behind its own opaque dark negative** — the code comment even says "4 mm in front", but the sign was negative. The develop-in effect rendered behind a solid dark rectangle.

**Fix:** the photo now sits 4 mm in front of the negative with `renderOrder: 1`; the dark negative remains as a visible backing border.

### 1.4 The cake slice floated above the plate
`Ceremony.js` ended the slice ~0.4 m above the plate — a visibly floating slice at the payoff of the cut beat.

**Fix:** the slice now arcs out along the wedge and lands **on** the plate (`plateTop − sliceBottom`), verified numerically (slice bottom == plate top, ±2 mm).

### 1.5 Wish cards / indoor confetti (covered by 1.1)
After the tag fix, cards fade in staggered across the gifts→wishes window and fade out by the stairfoot; confetti follows the same window. Verified visible (opacity 0.94→0.02 stagger) at the window mid-point.

### 1.6 Photographs were being stretched
`p01`, `p16`, `p17` are not 3:4 crops (1.194 / 1.370 / 1.237 h/w). Every frame forced them into ~1.33, quietly stretching them 7–11 % — and the magic mirror's fixed 0.72×1.55 m plane squashed its portrait photo by ~40 %, same for the constellation hover previews.

**Fix:** `PhotoFrame.js` now ships `PHOTO_RATIOS` and every frame honours the photo's true aspect ratio; the mirror and constellation previews size their planes per photo.

### 1.7 The mirror floated off the wall
The gilt mirror's frame front stopped ~4–11 cm short of the interior plaster.

**Fix:** moved flush against the wall (bezel ~7 mm proud), still 100 % readable from the gallery→hallway camera path.

### 1.8 A wish lantern hung 0.6 m from the camera stop
At the room-of-wishes key the camera stopped 0.66 m from a lantern that sat dead-centre in the lens.

**Fix:** lantern rows moved deeper into the room (z −2.4 / −3.8) with the middle lanterns staggered sideways — nearest approach is now ~1.5 m (swept the whole walk, 40 samples).

### 1.9 The moon was being fogged
`FogExp2` dimmed the ~220 m-distant moon by ~30 %, and because the fog density itself is animated during the intro, the moon visibly brightened/dimmed while scrolling (inconsistent brightness).

**Fix:** `fog: false` on the moon mesh and its halo (the moon is a light source, not atmosphere).

### 1.10 Memory-wall spotlight was blowing out the centre frames
The gallery wash was a 26-intensity, 0.95-rad spot aimed dead-centre: the two middle frames sat ~4× brighter than the corners.

**Fix:** softened to 17 intensity, angle 1.05, penumbra 0.85 — hierarchy kept, blow-out gone.

### 1.11 The film-projector tick never played
`scenes.js` calls `BdayAudio.tick()` on every slide change, but `audio.js` never exported `tick` — the guard made it fail silently.

**Fix:** exported.

---

## 2. What was verified clean (no changes needed)

- **Camera path** — 900 spline samples per viewport vs. reconstructed wall/slab AABBs: 0 intersections; floor bands correct at every key; camera rides the stair treads (deviation < 0.25 m, x < 0.6 m from the centre line); clearances to cake, gifts, lanterns, negatives all hold.
- **Signage** — raycast from all 9 approach keys: DIPIN nameplate and 16 OCTOBER 2006 plaque unobstructed (glass and additive planes ignored as intended).
- **Cake ceremony** — candles grow to scale ~1 by the candles key; flames lit by the light beat; knife visible mid-cut; slice/gap appear on the slice beat; nothing visible before the ceremony.
- **Reverse scrubbing** — knife/slice/smoke state fully reproducible after forward→backward→forward; no NaN in a 120-step sweep; whole-page scrub cycle logged 0 JS errors.
- **Gifts** — every photo rises clear of its box (bottom ≥ box top + 0.02 m).
- **Mirror** — reveal ≥ 0.85 shortly after the hallway key, fully faded by climb5.
- **Rooftop reveal** — text invisible before the terrace, fully up at the reveal key.
- **Darkroom** — all three photos develop mid-darkroom, now in front of their negatives.
- **Window wake** — 23 panes animate within sane emissive ranges.
- **DOM scenes** — years (21 ticks, majors 2006–2026, 16 small numerals, moon/stars/now light), corridor (8 slides, roman numerals I–VIII, polaroid), road (5 coaches with photos, 4 smoke puffs, 11 poles), celebration (4 photos, garland bulbs), finale (6 cluster photos, star sim, split name), rail (7 dots).
- **House captions** — every window has t0 < t1, zero overlaps, and the live caption matches its window at every mid-point while scrolling.
- **Cinema mode** — watch button hides the gate, shows the hint, auto-scrolls, and hands control back on wheel/tap.
- **Performance** — ~145 draw calls, ~310 k triangles at the memory wall and terrace (desktop).

## 3. Files changed

| File | Change |
|---|---|
| `js/house/CameraRig.js` | unique `wishroom` tag; darkroom door keys; mobile push-back list |
| `js/house/Architecture.js` | darkroom shed door widened 1.05 → 1.2 m |
| `js/house/Interiors.js` | dev-photo in front of negative; lantern layout; gallery spot softened |
| `js/house/Magic.js` | mirror flush on wall; mirror + constellation preview aspect |
| `js/house/PhotoFrame.js` | `PHOTO_RATIOS` map; frames honour true photo aspect |
| `js/house/Environment.js` | moon + halo `fog: false` |
| `js/house/Ceremony.js` | slice lands on the plate |
| `js/audio.js` | export `tick` |

The opening/parallax scene, the years interlude, the memory film, the night train, the celebration, the finale, all photographs, the audio score and the house's structure/camera journey were otherwise left exactly as authored.
